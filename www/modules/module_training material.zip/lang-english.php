<?php
define("_MODULE_LEAFLET_MODULELEAFLET", "Training Material");
define("_MODULE_LEAFLET_FILESLIST", "Files list");
define("_MODULE_LEAFLET_MANAGEFILES", "Manage files");
?>
