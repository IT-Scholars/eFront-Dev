<?php
define("_MODULE_SHARED_FILES_SHAREDFILES", "Shared files");
define("_MODULE_SHARED_FILES_SETSHARESTATUS", "Set share status");
define("_MODULE_SHARED_FILES_SHAREDFILESENABLED", "The system's default 'shared files' functionality is now disabled, since it's not compatible with this module");
?>
