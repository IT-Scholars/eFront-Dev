<?php
define("_YOUTUBE","ИоуТубе");//YouTube
define("_YOUTUBE_YOUTUBELIST","ИоуТубе линкови листу");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Додај видео линк");//Add video link
define("_YOUTUBE_PREVIEW","Видео Снапсхот");//Video snapshot
define("_YOUTUBE_NAME","Име видео");//Video name
define("_YOUTUBE_VIDEOLINK","ИоуТубе видео линка");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","ИоуТубе видео линка унос се не може направити");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Суццесфилли убаци видео линка");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Успешно ажуриран видео линка");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Измени видео линк");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Брисање видео-везе");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Да ли сте сигурни да желите да избришете овај видео линка из листе");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Видео Линкови успешно избрисане");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","ИоуТубе видео листа је празна");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Опис");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Видео податке");//Video data
define("_YOUTUBE_MANAGEMENT","Видео менаџмент");//Video management
define("_YOUTUBE_PREVIOUS","Претходни");//Previous
define("_YOUTUBE_NEXT","Следећа");//Next
define("_YOUTUBE_EXAMPLE","Пример");//Example
?>
