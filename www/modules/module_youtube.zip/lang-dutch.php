<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube koppelingen lijst");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Add video-link");//Add video link
define("_YOUTUBE_PREVIEW","Video snapshot");//Video snapshot
define("_YOUTUBE_NAME","Video naam");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link item kan niet worden gemaakt");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly ingevoegd video-link");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Bijgewerkt video-link");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Video link");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Delete video-link");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Weet u zeker dat u deze video wilt verwijderen uit de lijst link");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video-links succesvol verwijderd");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Het YouTube-video-lijst is leeg");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Beschrijving");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video gegevens");//Video data
define("_YOUTUBE_MANAGEMENT","Video-beheer");//Video management
define("_YOUTUBE_PREVIOUS","Vorige");//Previous
define("_YOUTUBE_NEXT","Volgende");//Next
define("_YOUTUBE_EXAMPLE","Voorbeeld");//Example
?>
