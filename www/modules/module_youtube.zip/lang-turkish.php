<?php
define("_YOUTUBE","YouTube");
define("_YOUTUBE_YOUTUBELIST", "YouTube bağlantı listesi");
define("_YOUTUBE_ADDYOUTUBE", "Video bağlantısı ekle");
define("_YOUTUBE_PREVIEW", "Video anlık görüntüsü");
define("_YOUTUBE_NAME", "Video ismi");
define("_YOUTUBE_VIDEOLINK", "YouTube video bağlantsı");
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY", "YouTube video bağlantı girişi oluşturulamadı");
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY", "Video bağlantısı başarıyla eklendi");
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY", "Video bağlantısı başarıyla güncellendi");
define("_YOUTUBE_EDITYOUTUBE", "Video bağlantısını düzenle");
define("_YOUTUBE_DELETEYOUTUBE", "Video bağlantısını sil");
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Bu video bağlantısını listeden silmek istediğinizden eminmisiniz");
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video bağlantısı başarıyla silindi");
define("_YOUTUBENOMEETINGSCHEDULED","YouTube video listesi boş");
define("_YOUTUBE_DESCRIPTION", "Açıklama");
define("_YOUTUBE_YOUTUBEVIDEODATA","Video verisi");
define("_YOUTUBE_MANAGEMENT","Video yönetimi");
define("_YOUTUBE_PREVIOUS", "Önceki");
define("_YOUTUBE_NEXT", "Sonraki");
define("_YOUTUBE_EXAMPLE", "Örnek");
?>