<?php
define("_YOUTUBE","ユーチューブ");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTubeの一覧のリンク");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","ビデオリンクを追加");//Add video link
define("_YOUTUBE_PREVIEW","ビデオスナップショット");//Video snapshot
define("_YOUTUBE_NAME","ビデオ名");//Video name
define("_YOUTUBE_VIDEOLINK","YouTubeのビデオリンク");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTubeのビデオリンクのエントリを作成できませんでした");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfyllyビデオリンクを挿入");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","ビデオリンクが正常に更新");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","編集ビデオリンク");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","ビデオリンクを削除");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","あなたのリストから、このビデオリンクを削除してもよろしいです");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","ビデオが正常に削除されたリンク");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","は、 YouTubeのビデオリストは空です");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","説明");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","ビデオデータ");//Video data
define("_YOUTUBE_MANAGEMENT","ビデオ管理");//Video management
define("_YOUTUBE_PREVIOUS","前");//Previous
define("_YOUTUBE_NEXT","次の");//Next
define("_YOUTUBE_EXAMPLE","例");//Example
?>
