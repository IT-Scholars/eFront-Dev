<?php
define("_YOUTUBE","YouTube");
define("_YOUTUBE_YOUTUBELIST", "YouTube links list");
define("_YOUTUBE_ADDYOUTUBE", "Add video link");
define("_YOUTUBE_PREVIEW", "Video snapshot");
define("_YOUTUBE_NAME", "Video name");
define("_YOUTUBE_VIDEOLINK", "YouTube video link");
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY", "YouTube video link entry could not be created");
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY", "Succesfylly inserted video link");
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY", "Succesfully updated video link");
define("_YOUTUBE_EDITYOUTUBE", "Edit video link");
define("_YOUTUBE_DELETEYOUTUBE", "Delete video link");
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Are you sure you want to delete this video link from the list");
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video links deleted succesfully");
define("_YOUTUBENOMEETINGSCHEDULED","The YouTube video list is empty");
define("_YOUTUBE_DESCRIPTION", "Description");
define("_YOUTUBE_YOUTUBEVIDEODATA","Video data");
define("_YOUTUBE_MANAGEMENT","Video management");
define("_YOUTUBE_PREVIOUS", "Previous");
define("_YOUTUBE_NEXT", "Next");
define("_YOUTUBE_EXAMPLE", "Example");
?>