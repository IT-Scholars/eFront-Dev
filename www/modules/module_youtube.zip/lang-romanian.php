<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube lista de link-uri");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Adauga link-ul de video");//Add video link
define("_YOUTUBE_PREVIEW","Video versiune snapshot");//Video snapshot
define("_YOUTUBE_NAME","Video numele");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link-ul de");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link-ul de intrare nu a putut fi creat");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly inserează link-ul de video");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Au fost actualizate cu succes video leagă aici");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Editare video leagă aici");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Ştergere video leagă aici");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Sunteţi sigur că doriţi să ştergeţi acest video link-ul din lista de");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video link-uri a fost şters cu succes");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube video lista este gol");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Descriere");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video date");//Video data
define("_YOUTUBE_MANAGEMENT","Management video");//Video management
define("_YOUTUBE_PREVIOUS","Înapoi");//Previous
define("_YOUTUBE_NEXT","Următorul");//Next
define("_YOUTUBE_EXAMPLE","Exemplu");//Example
?>
