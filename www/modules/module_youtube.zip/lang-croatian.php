<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube linkovi lista");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Dodaj video veze");//Add video link
define("_YOUTUBE_PREVIEW","Video snimak");//Video snapshot
define("_YOUTUBE_NAME","Video ime");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link zapis nije mogla biti kreirana");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly umetnuti video veze");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Uspješno ažuriran video veze");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Uredi video veze");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Obriši video veze");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Jeste li sigurni da želite izbrisati ovaj video vezu s popisa");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video linkovi uspješno obrisan");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Na YouTube video Lista je prazna");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Opis");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video podaci");//Video data
define("_YOUTUBE_MANAGEMENT","Video upravljanje");//Video management
define("_YOUTUBE_PREVIOUS","Prethodna");//Previous
define("_YOUTUBE_NEXT","Dalje");//Next
define("_YOUTUBE_EXAMPLE","Primjer");//Example
?>
