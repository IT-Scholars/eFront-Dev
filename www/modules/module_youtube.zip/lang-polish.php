<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube lista linków");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Dodaj link wideo");//Add video link
define("_YOUTUBE_PREVIEW","Video migawki");//Video snapshot
define("_YOUTUBE_NAME","Nazwa wideo");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link wpis nie może zostać utworzony");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly dodaje wideo link");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Pomyślnie zaktualizowane łącza wideo");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Edycja wideo link");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Usuń video link");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Czy na pewno chcesz usunąć ten film wideo związek z listy");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Łączy wideo został usunięty");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube video lista jest pusta");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Opis");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Danych wideo");//Video data
define("_YOUTUBE_MANAGEMENT","Video zarządzania");//Video management
define("_YOUTUBE_PREVIOUS","Poprzednia");//Previous
define("_YOUTUBE_NEXT","Następny");//Next
define("_YOUTUBE_EXAMPLE","Przykład");//Example
?>
