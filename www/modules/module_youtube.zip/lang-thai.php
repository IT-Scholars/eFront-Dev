<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube รายการการเชื่อมโยง");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","เพิ่มลิงค์วิดีโอ");//Add video link
define("_YOUTUBE_PREVIEW","จับภาพวิดีโอ");//Video snapshot
define("_YOUTUBE_NAME","ชื่อวิดีโอ");//Video name
define("_YOUTUBE_VIDEOLINK","ลิงค์วิดีโอ YouTube");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube รายการลิงค์วิดีโอไม่สามารถสร้างได้");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly แทรกลิงค์วิดีโอ");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","การปรับปรุงเรียบร้อยแล้วลิงค์วิดีโอ");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","แก้ไขลิงค์วิดีโอ");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","ลบลิงค์วิดีโอ");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","คุณแน่ใจหรือว่าต้องการลบรายการนี้ลิงค์วิดีโอจากรายการ");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","วิดีโอลิงค์ลบแล้ว");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","รายการวิดีโอ YouTube ว่างเปล่า");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","ลักษณะ");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","ข้อมูลวิดีโอ");//Video data
define("_YOUTUBE_MANAGEMENT","การจัดการวิดีโอ");//Video management
define("_YOUTUBE_PREVIOUS","ก่อน");//Previous
define("_YOUTUBE_NEXT","ถัดไป");//Next
define("_YOUTUBE_EXAMPLE","ตัวอย่างเช่น");//Example
?>
