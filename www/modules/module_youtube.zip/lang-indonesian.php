<?php
define("_YOUTUBE", "YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST", "Daftar tautan YouTube");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE", "Tambahkan tautan video");//Add video link
define("_YOUTUBE_PREVIEW", "Video snapshot");//Video snapshot
define("_YOUTUBE_NAME", "Nama video");//Video name
define("_YOUTUBE_VIDEOLINK", "Tautan video YouTube");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY", "Entri tautan video YouTube tidak dapat dibuat");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY", "Tautan video berhasil disisipkan");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY", "Tautan video berhasil diperbarui");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE", "Sunting tautan video");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE", "Hapus tautan video");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT", "Apakah anda yakin ingin menghapus tautan video ini dari daftar");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY", "Tautan video berhasil dihapus");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED", "Daftar video YouTube kosong");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION", "Deskripsi");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA", "Data video");//Video data
define("_YOUTUBE_MANAGEMENT", "Pengelolaan Video");//Video management
define("_YOUTUBE_PREVIOUS", "Sebelumnya");//Previous
define("_YOUTUBE_NEXT", "Selanjutnya");//Next
define("_YOUTUBE_EXAMPLE", "Contoh");//Example
?>