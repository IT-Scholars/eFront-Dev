<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube, nuorodų sąrašą");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Pridėti nuorodą į vaizdo įrašą");//Add video link
define("_YOUTUBE_PREVIEW","Vaizdo fotografiją");//Video snapshot
define("_YOUTUBE_NAME","Dainos pavadinimas");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video įrašas negali būti sukurtas");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly įterpiamas nuorodą į vaizdo įrašą");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Sėkmingai atnaujinta nuorodą į vaizdo įrašą");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Vaizdo ryšys");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Ištrinti nuorodą į vaizdo įrašą");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Ar tikrai norite ištrinti šią nuorodą į vaizdo įrašą iš sąrašo");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Vaizdo nuorodos sėkmingai ištrintas");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube vaizdo sąrašas tuščias");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Aprašymas");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Vaizdo duomenų");//Video data
define("_YOUTUBE_MANAGEMENT","Vaizdo valdymas");//Video management
define("_YOUTUBE_PREVIOUS","Ankstesnis");//Previous
define("_YOUTUBE_NEXT","Kitas");//Next
define("_YOUTUBE_EXAMPLE","Pavyzdys");//Example
?>