<?php
define("_YOUTUBE","YouTube에서");//YouTube
define("_YOUTUBE_YOUTUBELIST","유튜브 링크 목록");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","동영상 링크를 추가");//Add video link
define("_YOUTUBE_PREVIEW","비디오 스냅샷");//Video snapshot
define("_YOUTUBE_NAME","비디오 이름");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube 동영상 링크");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube 동영상 링크 항목을 만들 수 없습니다");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly 동영상 링크를 삽입");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","성공적으로 동영상 링크를 업데이 트");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","동영상 링크 편집");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","삭제 동영상 링크");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","정말 당신이 목록에서 동영상 링크를 삭제하려면");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","동영상이 성공적으로 삭제 링크");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube 동영상 목록이 비어 있습니다");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","설명");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","비디오 데이터");//Video data
define("_YOUTUBE_MANAGEMENT","비디오 관리");//Video management
define("_YOUTUBE_PREVIOUS","이전");//Previous
define("_YOUTUBE_NEXT","다음");//Next
define("_YOUTUBE_EXAMPLE","예를 들어");//Example
?>
