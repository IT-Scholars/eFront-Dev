<?php
define("_YOUTUBE","يوتيوب");//YouTube
define("_YOUTUBE_YOUTUBELIST","يوتيوب قائمة الروابط");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","إضافة وصلة فيديو");//Add video link
define("_YOUTUBE_PREVIEW","لقطة فيديو");//Video snapshot
define("_YOUTUBE_NAME","اسم الفيديو");//Video name
define("_YOUTUBE_VIDEOLINK","وصلة فيديو يوتيوب");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","وصلة فيديو يوتيوب دخول لا يمكن خلق");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly إدراج وصلة فيديو");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","نجحت عملية تحديث وصلة فيديو");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","تحرير وصلة فيديو");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","حذف وصلة فيديو");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","هل أنت متأكد من أنك تريد حذف هذه وصلة فيديو من قائمة");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","وصلات الفيديو حذف بنجاح");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","وقد يوتيوب فيديو القائمة فارغة");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","الوصف");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","بيانات الفيديو");//Video data
define("_YOUTUBE_MANAGEMENT","الفيديو الإدارة");//Video management
define("_YOUTUBE_PREVIOUS","السابق");//Previous
define("_YOUTUBE_NEXT","التالي");//Next
define("_YOUTUBE_EXAMPLE","مثال");//Example
?>
