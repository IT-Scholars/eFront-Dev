<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube links listahan");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Magdagdag ng video link");//Add video link
define("_YOUTUBE_PREVIEW","Video snapshot");//Video snapshot
define("_YOUTUBE_NAME","Video pangalan");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link entry ay hindi malikha");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly nakapasok video link");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Matagumpay na nai-update na video link");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","I-edit ang video link");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Tanggalin ang video link");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Sigurado ka bang gusto mong burahin ang video na link mula sa listahan");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video link matagumpay na tinanggal");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Ang listahan ng YouTube video na ito ay walang laman");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Paglalarawan");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video data");//Video data
define("_YOUTUBE_MANAGEMENT","Video management");//Video management
define("_YOUTUBE_PREVIOUS","Nakaraan");//Previous
define("_YOUTUBE_NEXT","Susunod");//Next
define("_YOUTUBE_EXAMPLE","Halimbawa");//Example
?>
