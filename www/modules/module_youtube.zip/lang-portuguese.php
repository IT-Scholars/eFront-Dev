<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","Lista de links YouTube");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Adicionar link de vídeo");//Add video link
define("_YOUTUBE_PREVIEW","Vídeo instantâneo");//Video snapshot
define("_YOUTUBE_NAME","Titulo do Vídeo");//Video name
define("_YOUTUBE_VIDEOLINK","Link de vídeo do YouTube");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","Link de vídeo YouTube não pode ser criado");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Link de vídeo inserido com sucesso");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Link de vídeo atualizado com sucesso");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Editar link de vídeo");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Excluír link de vídeo");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Tem certeza de que deseja apagar este link de vídeo a partir da lista");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Link de vídeo excluído com sucesso");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","A lista de links de vídeo YouTube está vazia");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Descrição");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Dados do vídeo");//Video data
define("_YOUTUBE_MANAGEMENT","Gerenciar vídeos");//Video management
define("_YOUTUBE_PREVIOUS","Anterior");//Previous
define("_YOUTUBE_NEXT","Próximo");//Next
define("_YOUTUBE_EXAMPLE","Exemplo");//Example
?>
