<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube ΰ¤Έΰ¥‚ΰ¤ΰ¥€ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•ΰ¥ΰ¤Έ");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¥‡ΰ¤‚");//Add video link
define("_YOUTUBE_PREVIEW","ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤Έΰ¥ΰ¤¨ΰ¥ΰ¤ΰ¤¶ΰ¥‰ΰ¤");//Video snapshot
define("_YOUTUBE_NAME","ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤¨ΰ¤Ύΰ¤®");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤•ΰ¤΅ΰ¤Όΰ¥€ ΰ¤ΰ¥ΰ¤°ΰ¤µΰ¥‡ΰ¤¶ ΰ¤¨ΰ¤Ήΰ¥€ΰ¤‚ ΰ¤¬ΰ¤¨ΰ¤Ύΰ¤―ΰ¤Ύ ΰ¤ΰ¤Ύ ΰ¤Έΰ¤•ΰ¤¤ΰ¤Ύ ΰ¤Ήΰ¥");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤΅ΰ¤Ύΰ¤²ΰ¤Ύ");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤…ΰ¤¦ΰ¥ΰ¤―ΰ¤¤ΰ¤¨");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","ΰ¤Έΰ¤‚ΰ¤ΰ¤Ύΰ¤¦ΰ¤Ώΰ¤¤ ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","ΰ¤Ήΰ¤ΰ¤Ύΰ¤ΰ¤ ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","ΰ¤•ΰ¥ΰ¤―ΰ¤Ύ ΰ¤†ΰ¤ ΰ¤Έΰ¥‚ΰ¤ΰ¥€ ΰ¤Έΰ¥‡ ΰ¤‡ΰ¤Έ ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤•ΰ¥‹ ΰ¤¨ΰ¤·ΰ¥ΰ¤ ΰ¤•ΰ¤°ΰ¤¨ΰ¤Ύ ΰ¤ΰ¤Ύΰ¤Ήΰ¤¤ΰ¥‡ ΰ¤Ήΰ¥ΰ¤‚");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤¨ΰ¤·ΰ¥ΰ¤ ΰ¤•ΰ¤° ΰ¤¦ΰ¤Ώΰ¤―ΰ¤Ύ ΰ¤—ΰ¤―ΰ¤Ύ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","ΰ¤‡ΰ¤Έ ΰ¤―ΰ¥‚ΰ¤ΰ¥ΰ¤―ΰ¥‚ΰ¤¬ ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤Έΰ¥‚ΰ¤ΰ¥€ ΰ¤–ΰ¤Ύΰ¤²ΰ¥€ ΰ¤Ήΰ¥");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","ΰ¤µΰ¤°ΰ¥ΰ¤£ΰ¤¨");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤΅ΰ¥‡ΰ¤ΰ¤Ύ");//Video data
define("_YOUTUBE_MANAGEMENT","ΰ¤µΰ¥€ΰ¤΅ΰ¤Ώΰ¤―ΰ¥‹ ΰ¤ΰ¥ΰ¤°ΰ¤¬ΰ¤‚ΰ¤§ΰ¤¨");//Video management
define("_YOUTUBE_PREVIOUS","ΰ¤ΰ¤Ώΰ¤›ΰ¤²ΰ¥‡");//Previous
define("_YOUTUBE_NEXT","ΰ¤…ΰ¤—ΰ¤²ΰ¤Ύ");//Next
define("_YOUTUBE_EXAMPLE","ΰ¤‰ΰ¤¦ΰ¤Ύΰ¤Ήΰ¤°ΰ¤£");//Example
?>
