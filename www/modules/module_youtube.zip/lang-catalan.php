<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube llista d&#39;enllaços");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Afegeix enllaç de vídeo");//Add video link
define("_YOUTUBE_PREVIEW","Instantània de Vídeo");//Video snapshot
define("_YOUTUBE_NAME","Video nom");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","vídeo de YouTube entrada vincle no es pot crear");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly s&#39;insereix enllaç de vídeo");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Actualitzat correctament enllaç de vídeo");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Edita enllaç de vídeo");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Eliminar enllaç de vídeo");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Estàs segur que vols eliminar aquest enllaç de vídeo de la llista");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video enllaços eliminat amb èxit");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","La llista de vídeos YouTube està buida");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Descripció");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video de dades");//Video data
define("_YOUTUBE_MANAGEMENT","De gestió de vídeo");//Video management
define("_YOUTUBE_PREVIOUS","Anterior");//Previous
define("_YOUTUBE_NEXT","Següent");//Next
define("_YOUTUBE_EXAMPLE","Exemple");//Example
?>
