<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube רשימת קישורים");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","הוסף קישור וידאו");//Add video link
define("_YOUTUBE_PREVIEW","וידאו תמונת מצב");//Video snapshot
define("_YOUTUBE_NAME","וידאו שם");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube הקישור וידאו");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","קישור YouTube כניסת וידאו לא ניתן ליצור");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","הוכנס Succesfylly קישור וידאו");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","עודכן בהצלחה קישור וידאו");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","הקישור עריכה וידאו");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","וידאו מחק הקישור");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","האם אתה בטוח שאתה רוצה למחוק קישור זה וידאו מתוך הרשימה");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","וידאו קישורים נמחק בהצלחה");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","רשימת וידאו YouTube ריקה");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","תיאור");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","נתוני וידאו");//Video data
define("_YOUTUBE_MANAGEMENT","וידאו וניהול");//Video management
define("_YOUTUBE_PREVIOUS","קודם");//Previous
define("_YOUTUBE_NEXT","הבא");//Next
define("_YOUTUBE_EXAMPLE","לדוגמה");//Example
?>
