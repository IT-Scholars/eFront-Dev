<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube link elenco");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Aggiungi collegamento video");//Add video link
define("_YOUTUBE_PREVIEW","Istantanea video");//Video snapshot
define("_YOUTUBE_NAME","Nome video");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link ingresso potrebbe non essere creato");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly inserito collegamento video");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Aggiornati collegamento video");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Modifica collegamento video");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Elimina collegamento video");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Sei sicuro di voler eliminare questo collegamento video dalla lista");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video collegamenti soppressi con successo");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Il video di YouTube elenco è vuoto");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Descrizione");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video dati");//Video data
define("_YOUTUBE_MANAGEMENT","Gestione video");//Video management
define("_YOUTUBE_PREVIOUS","Precedente");//Previous
define("_YOUTUBE_NEXT","Successivo");//Next
define("_YOUTUBE_EXAMPLE","Esempio");//Example
?>
