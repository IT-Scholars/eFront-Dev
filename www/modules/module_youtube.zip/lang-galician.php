<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube lista de ligazóns");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Engadir ligazón de vídeo");//Add video link
define("_YOUTUBE_PREVIEW","snapshot do vídeo");//Video snapshot
define("_YOUTUBE_NAME","Nome do Vídeo");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video ligazón");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube entrada enlace do vídeo non puido crear");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly inseridos enlace de vídeo");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Actualizado correctamente enlace de vídeo");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Editar enlace de vídeo");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","video ligazón Eliminar");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","¿Está seguro de querer eliminar este enlace de video na lista");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Vídeo ligazóns borrado con éxito");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","A lista de vídeos YouTube está baleiro");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Descrición");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Os datos de vídeo");//Video data
define("_YOUTUBE_MANAGEMENT","xestión de vídeo");//Video management
define("_YOUTUBE_PREVIOUS","Anterior");//Previous
define("_YOUTUBE_NEXT","Seguinte");//Next
define("_YOUTUBE_EXAMPLE","Exemplo");//Example
?>
