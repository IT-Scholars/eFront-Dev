<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","Lista de enlaces a YouTube");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Añadir vídeo");//Add video link
define("_YOUTUBE_PREVIEW","Video instantánea");//Video snapshot
define("_YOUTUBE_NAME","Video nombre");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link de entrada no puede ser creado");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly inserta una conexión de vídeo");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Actualizado con éxito una conexión de vídeo");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Editar vídeo");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Eliminar una conexión de vídeo");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","¿Estás seguro de que desea eliminar este enlace de vídeo de la lista");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Enlaces de vídeo suprimido con éxito");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","La lista de vídeos YouTube está vacía");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Descripción");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Datos de vídeo");//Video data
define("_YOUTUBE_MANAGEMENT","Video de gestión");//Video management
define("_YOUTUBE_PREVIOUS","Anterior");//Previous
define("_YOUTUBE_NEXT","Siguiente");//Next
define("_YOUTUBE_EXAMPLE","Ejemplo");//Example
?>
