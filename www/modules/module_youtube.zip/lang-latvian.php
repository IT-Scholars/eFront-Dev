<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube saišu sarakstu");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Pievienot video link");//Add video link
define("_YOUTUBE_PREVIEW","Video momentuzņēmums");//Video snapshot
define("_YOUTUBE_NAME","Video nosaukums");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video saites");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video saites ierakstu nevar izveidot");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly ievietota video saites");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Veiksmīgi atjaunināta video saites");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Rediģēt video saites");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Dzēst video saites");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Vai tiešām vēlaties dzēst šo video saites no saraksta");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video saites veiksmīgi izdzēsts");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube video saraksts ir tukšs");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Apraksts");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video datu");//Video data
define("_YOUTUBE_MANAGEMENT","Video vadība");//Video management
define("_YOUTUBE_PREVIOUS","Iepriekšējais");//Previous
define("_YOUTUBE_NEXT","Nākamā");//Next
define("_YOUTUBE_EXAMPLE","Piemēram");//Example
?>
