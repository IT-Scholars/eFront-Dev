<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube danh sách liên kết");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Thêm liên kết video");//Add video link
define("_YOUTUBE_PREVIEW","Video snapshot");//Video snapshot
define("_YOUTUBE_NAME","Video tên");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video liên kết");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video vào liên kết không thể được tạo ra");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly chèn liên kết video");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Cập nhật thành công liên kết video");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Liên kết chỉnh sửa video");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Xóa liên kết video");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Bạn có chắc chắn muốn xóa liên kết này video từ danh sách");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video liên kết xoá thành công");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Danh sách video YouTube có sản phẩm nào");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Mô tả");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video dữ liệu");//Video data
define("_YOUTUBE_MANAGEMENT","Video quản lý");//Video management
define("_YOUTUBE_PREVIOUS","Trước");//Previous
define("_YOUTUBE_NEXT","Tiếp theo");//Next
define("_YOUTUBE_EXAMPLE","Ví dụ");//Example
?>
