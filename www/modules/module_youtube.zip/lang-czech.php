<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube odkazy seznam");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Přidat video odkaz");//Add video link
define("_YOUTUBE_PREVIEW","Video Snapshot");//Video snapshot
define("_YOUTUBE_NAME","Video jméno");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video odkaz");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video vstup souvislost nemohla být vytvořena");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly zní video odkaz");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Úspěšně videonatáčení aktualizován odkaz");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Úpravy videa odkaz");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Odstranit video odkaz");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Jste si jisti, že chcete smazat tento odkaz video ze seznamu");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Odkazy na videa byla úspěšně smazána");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Na YouTube video seznam je prázdný");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Popis");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video data");//Video data
define("_YOUTUBE_MANAGEMENT","Video řízení");//Video management
define("_YOUTUBE_PREVIOUS","Předchozí");//Previous
define("_YOUTUBE_NEXT","Příští");//Next
define("_YOUTUBE_EXAMPLE","Příklad");//Example
?>
