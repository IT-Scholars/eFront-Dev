<?php
define("_YOUTUBE","YouTube网站");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube的联系名单");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","新增视频链接");//Add video link
define("_YOUTUBE_PREVIEW","视频快照");//Video snapshot
define("_YOUTUBE_NAME","视频名称");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube视频链接");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube视频链接进入无法建立");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly插入视频链接");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","成功更新视频链接");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","编辑视频链接");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","删除视频链接");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","您是否确实要删除这个视频链接从名单");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","视频链接删除成功");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","在YouTube视频列表是空的");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","说明");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","视频数据");//Video data
define("_YOUTUBE_MANAGEMENT","视频管理");//Video management
define("_YOUTUBE_PREVIOUS","上一页");//Previous
define("_YOUTUBE_NEXT","下一个");//Next
define("_YOUTUBE_EXAMPLE","例如");//Example
?>
