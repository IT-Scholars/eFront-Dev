<?php
define("_YOUTUBE","YouTube網站");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube的聯繫名單");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","新增視頻鏈接");//Add video link
define("_YOUTUBE_PREVIEW","視頻快照");//Video snapshot
define("_YOUTUBE_NAME","視頻名稱");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube視頻鏈接");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube視頻鏈接進入無法建立");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly插入視頻鏈接");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","成功更新視頻鏈接");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","編輯視頻鏈接");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","刪除視頻鏈接");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","您是否確實要刪除這個視頻鏈接從名單");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","視頻鏈接刪除成功");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","在YouTube視頻列表是空的");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","說明");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","視頻數據");//Video data
define("_YOUTUBE_MANAGEMENT","視頻管理");//Video management
define("_YOUTUBE_PREVIOUS","上一頁");//Previous
define("_YOUTUBE_NEXT","下一個");//Next
define("_YOUTUBE_EXAMPLE","例如");//Example
?>
