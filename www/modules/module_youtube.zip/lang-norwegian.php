<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube-lenker listen");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Legg til video-link");//Add video link
define("_YOUTUBE_PREVIEW","Videostillbilde");//Video snapshot
define("_YOUTUBE_NAME","Video navn");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link oppføringen kunne ikke opprettes");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly inn video link");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Oppdatert video link");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Redigere video link");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Slett video-link");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Er du sikker på at du vil slette denne videoen link fra listen");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video lenker ble slettet");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube-videoen er tom");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Beskrivelse");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video data");//Video data
define("_YOUTUBE_MANAGEMENT","Video-styring");//Video management
define("_YOUTUBE_PREVIOUS","Forrige");//Previous
define("_YOUTUBE_NEXT","Neste");//Next
define("_YOUTUBE_EXAMPLE","Eksempel");//Example
?>
