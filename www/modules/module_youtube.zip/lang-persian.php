<?php
define("_YOUTUBE","یوتیوب");//YouTube
define("_YOUTUBE_YOUTUBELIST","یوتیوب لیست لینکها");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","اضافه کردن لینک ویدیو");//Add video link
define("_YOUTUBE_PREVIEW","عکس فوری ویدیو");//Video snapshot
define("_YOUTUBE_NAME","نام ویدیو");//Video name
define("_YOUTUBE_VIDEOLINK","یوتیوب لینک ویدیو");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","یوتیوب ویدیو ورود لینک نمی تواند ایجاد");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly درج لینک ویدیو");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","با موفقیت به روز شده لینک ویدیو");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","ویرایش لینک ویدیو");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","لینک ویدیو حذف");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","آیا مطمئن هستید که می خواهید پاک کنید این لینک ویدیو را از لیست");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","ویدیو لینک حذف شد");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","یوتیوب لیست ویدیو خالی است");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","شرح");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","ویدئو دیتا");//Video data
define("_YOUTUBE_MANAGEMENT","مدیریت ویدیو");//Video management
define("_YOUTUBE_PREVIOUS","قبلی");//Previous
define("_YOUTUBE_NEXT","بعدی");//Next
define("_YOUTUBE_EXAMPLE","مثال");//Example
?>
