<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube links lista");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Add link video");//Add video link
define("_YOUTUBE_PREVIEW","pamje Video");//Video snapshot
define("_YOUTUBE_NAME","Emri Video");//Video name
define("_YOUTUBE_VIDEOLINK","Lidhje YouTube video");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","Lidhje YouTube video hyrjes nuk mund të krijohet");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","futur Succesfylly lidhje video");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","përditësuar me sukses lidhje video");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Edit Lidhje video");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Lidhje Delete video");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","A jeni i sigurt se doni te e fshini kete link video nga lista");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video lidhje të fshirë me sukses");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Lista YouTube video është e zbrazët");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Përshkrim");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","dhënave Video");//Video data
define("_YOUTUBE_MANAGEMENT","menaxhimit Video");//Video management
define("_YOUTUBE_PREVIOUS","I mëparshëm");//Previous
define("_YOUTUBE_NEXT","Tjetër");//Next
define("_YOUTUBE_EXAMPLE","Shembull");//Example
?>
