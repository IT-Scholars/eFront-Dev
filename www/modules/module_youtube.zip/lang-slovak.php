<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube odkazy Zoznam");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Pridať odkaz na video");//Add video link
define("_YOUTUBE_PREVIEW","Video snímka");//Video snapshot
define("_YOUTUBE_NAME","Názov videa");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link zápis nemohol byť vytvorený");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly vložený odkaz na video");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Úspešne aktualizovaný odkaz na video");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Upraviť odkaz na video");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Odstrániť video link");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Ste si istí, že chcete zmazať toto video odkaz zo zoznamu");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Odkazy na videá úspešne zmazaný");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Video YouTube zoznam je prázdny");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Popis");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video dáta");//Video data
define("_YOUTUBE_MANAGEMENT","Video management");//Video management
define("_YOUTUBE_PREVIOUS","Predchádzajúci");//Previous
define("_YOUTUBE_NEXT","Ďalší");//Next
define("_YOUTUBE_EXAMPLE","Príklad");//Example
?>
