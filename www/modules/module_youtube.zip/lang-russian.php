<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube списка ссылок");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Добавить видео связь");//Add video link
define("_YOUTUBE_PREVIEW","Видео снимок");//Video snapshot
define("_YOUTUBE_NAME","Видео название");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube видео-связь");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube видео связь вступление не может быть создана");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly вставить видео-связь");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Успешно обновлена видеосвязи");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Редактировать видео-связь");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Удалить видео-связь");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Вы действительно хотите удалить это видео ссылке из списка");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Видео успешно удалены ссылки");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube видео список пуст");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Описание");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Видео данные");//Video data
define("_YOUTUBE_MANAGEMENT","Видео управление");//Video management
define("_YOUTUBE_PREVIOUS","Предыдущая");//Previous
define("_YOUTUBE_NEXT","Следующий");//Next
define("_YOUTUBE_EXAMPLE","Пример");//Example
?>
