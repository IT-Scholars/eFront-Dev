<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube linkek listáját");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Add video link");//Add video link
define("_YOUTUBE_PREVIEW","Videó pillanatfelvétel");//Video snapshot
define("_YOUTUBE_NAME","Videonév");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube videó link");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube videó link bejegyzés nem hozható létre");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly ki video link");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Sikeresen frissítve video link");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Szerkesztés video link");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Törlés video link");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Biztos benne, hogy törli ezt a videót a linket a listáról");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Videó linkek sikeresen törölve");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","A YouTube videó lista üres");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Leírás");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Videó adatok");//Video data
define("_YOUTUBE_MANAGEMENT","Videokezelő");//Video management
define("_YOUTUBE_PREVIOUS","Előző");//Previous
define("_YOUTUBE_NEXT","Következő");//Next
define("_YOUTUBE_EXAMPLE","Példa");//Example
?>
