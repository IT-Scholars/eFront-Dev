<?php
define("_YOUTUBE","YouTube");
define("_YOUTUBE_YOUTUBELIST", "YouTube λίστα");
define("_YOUTUBE_ADDYOUTUBE", "Προσθήκη βίντεο");
define("_YOUTUBE_PREVIEW", "Εικόνα βίντεο");
define("_YOUTUBE_NAME", "Όνομα βίντεο");
define("_YOUTUBE_VIDEOLINK", "YouTube σύνδεσμος");
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY", "Ο σύνδεσμος για αυτό το YouTube βίντεο δεν ήταν δυνατό να δημιουργηθεί");
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY", "Το βίντεο καταχωρήθηκε επιτυχώς");
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY", "Τα στοιχεία του βίντεο άλλαξαν επιτυχώς");
define("_YOUTUBE_EDITYOUTUBE", "Επεξεργασία στοιχείων βίντεο");
define("_YOUTUBE_DELETEYOUTUBE", "Διαγραφή βίντεο");
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Είστε σίγουροι ότι θέλετε να διαγράψετε το βίντεο αυτό από τη λίστα;");
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Το βίντεο διαγράφηκε επιτυχώς από τη λίστα");
define("_YOUTUBENOMEETINGSCHEDULED","Η λίστα με YouTube βίντεο είναι κενή");
define("_YOUTUBE_DESCRIPTION", "Περιγραφή");
define("_YOUTUBE_YOUTUBEVIDEODATA","Πληροφορίες βίντεο");
define("_YOUTUBE_MANAGEMENT","Επεξεργασία βίντεο");
define("_YOUTUBE_PREVIOUS", "Προηγούμενο");
define("_YOUTUBE_NEXT", "Επόμενο");
define("_YOUTUBE_EXAMPLE", "Παράδειγμα");

?>