<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube връзки списък");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Добавяне на видео връзка");//Add video link
define("_YOUTUBE_PREVIEW","Видео моментална снимка");//Video snapshot
define("_YOUTUBE_NAME","Видео име");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube видео връзка");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube видео връзка вписване не може да бъде създаден");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly добавя видео връзка");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Успешно осъвременяване на видео връзка");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Редактиране на видео връзка");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Изтриване на видео връзка");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Сигурни ли сте, че искате да изтриете това видео връзка от списъка");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Видео връзки изтрит успешно");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","В YouTube видео Списъкът е празен");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Описание");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Видео данни");//Video data
define("_YOUTUBE_MANAGEMENT","Видео управление");//Video management
define("_YOUTUBE_PREVIOUS","Предишна");//Previous
define("_YOUTUBE_NEXT","Следващ");//Next
define("_YOUTUBE_EXAMPLE","Пример");//Example
?>
