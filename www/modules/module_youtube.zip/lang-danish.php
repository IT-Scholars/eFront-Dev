<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube links liste");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Tilføj video-link");//Add video link
define("_YOUTUBE_PREVIEW","Video øjebliksbillede");//Video snapshot
define("_YOUTUBE_NAME","Video navn");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video link indrejse kunne ikke oprettes");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly indsættes video-link");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Blevet opdateret video-link");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Rediger video-link");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Slet video-link");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Er du sikker på du vil slette denne video link fra listen");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video links slettet med succes!");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube video listen er tom");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Beskrivelse");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video data");//Video data
define("_YOUTUBE_MANAGEMENT","Video forvaltning");//Video management
define("_YOUTUBE_PREVIOUS","Forrige");//Previous
define("_YOUTUBE_NEXT","Næste");//Next
define("_YOUTUBE_EXAMPLE","Eksempel");//Example
?>
