<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube-Links-Liste");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Video-Link hinzufügen");//Add video link
define("_YOUTUBE_PREVIEW","Video-Snapshot");//Video snapshot
define("_YOUTUBE_NAME","Video Name");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube-Video Link");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube-Video-Link Eintrag konnte nicht erstellt werden");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Video-Link erfolgreich eingefügt");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Video-Link erfolgreich aktualisiert");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Video-Link bearbeiten");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Video-Link löschen");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Sind Sie sicher, dass Sie diesen Video-Link aus der Liste löschen möchten");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video-Links erfolgreich gelöscht");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Die YouTube-Video-Liste ist leer");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Beschreibung");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video-Daten");//Video data
define("_YOUTUBE_MANAGEMENT","Video-Management");//Video management
define("_YOUTUBE_PREVIOUS","Zurück");//Previous
define("_YOUTUBE_NEXT","Nächster");//Next
define("_YOUTUBE_EXAMPLE","Beispiel");//Example
?>
