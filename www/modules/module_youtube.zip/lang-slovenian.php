<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube povezav seznam");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Dodaj video povezave");//Add video link
define("_YOUTUBE_PREVIEW","Video posnetek");//Video snapshot
define("_YOUTUBE_NAME","Video ime");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube video povezavo");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube video povezavo vstopa ni mogoče ustvariti");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly Vstavi video povezave");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Uspešno posodobljene video povezave");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Urejanje video povezave");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Brisanje video povezave");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Ali ste prepričani, da želite izbrisati ta video povezave iz seznama");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video povezave uspešno izbrisana");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Video YouTube Seznam je prazen");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Opis");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Video podatki");//Video data
define("_YOUTUBE_MANAGEMENT","Video upravljanja");//Video management
define("_YOUTUBE_PREVIOUS","Prejšnja");//Previous
define("_YOUTUBE_NEXT","Naprej");//Next
define("_YOUTUBE_EXAMPLE","Primer");//Example
?>
