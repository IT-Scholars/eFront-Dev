<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube länkar lista");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Lägg till video länk");//Add video link
define("_YOUTUBE_PREVIEW","Video snapshot");//Video snapshot
define("_YOUTUBE_NAME","Video namn");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube-video länk");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube-video koppling posten kunde inte skapas");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly införas videolänk");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Har uppdaterats videolänk");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Redigera video länk");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Radera videolänk");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Är du säker på att du vill ta bort denna video länk från listan");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Videolänkar raderats");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube-video listan är tom");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Beskrivning");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Videodata");//Video data
define("_YOUTUBE_MANAGEMENT","Video förvaltning");//Video management
define("_YOUTUBE_PREVIOUS","Föregående");//Previous
define("_YOUTUBE_NEXT","Nästa");//Next
define("_YOUTUBE_EXAMPLE","Exempel");//Example
?>
