<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube-linkkien luettelo");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Lisää videon linkki");//Add video link
define("_YOUTUBE_PREVIEW","Video snapshot");//Video snapshot
define("_YOUTUBE_NAME","Videon nimi");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube-videon linkki");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube-videon linkki merkintä ei voi luoda");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly Lisätään videon linkki");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Päivittäminen onnistui videon linkki");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Videon linkki");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Poista videon linkki");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Oletko varma että haluat poistaa tämän videon linkki listalta");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Video-linkkejä poistettu");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","YouTube-video on tyhjä");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Kuvaus");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Videon tiedot");//Video data
define("_YOUTUBE_MANAGEMENT","Video-johto");//Video management
define("_YOUTUBE_PREVIOUS","Edellinen");//Previous
define("_YOUTUBE_NEXT","Seuraava");//Next
define("_YOUTUBE_EXAMPLE","Esimerkki");//Example
?>
