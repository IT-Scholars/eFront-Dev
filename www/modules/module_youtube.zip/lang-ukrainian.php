<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube список посилань");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Додати відео посилання");//Add video link
define("_YOUTUBE_PREVIEW","Video Snapshot");//Video snapshot
define("_YOUTUBE_NAME","Ім&#39;я відео");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube відеороликів на засланні");//YouTube video link
define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube відеороликів на засланні запис не може бути створена");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly вставити відеозв&#39;язку");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Успішно оновлення відеозв&#39;язку");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Редагування відео посилання");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Видалити посилання відео");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Ви впевнені, що хочете видалити цей відеозв&#39;язку зі списку");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Посилання на відео успішно видалений");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","Список YouTube відео порожній");//The YouTube video list is empty
define("_YOUTUBE_DESCRIPTION","Опис");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Відеоматеріали");//Video data
define("_YOUTUBE_MANAGEMENT","Управління відео");//Video management
define("_YOUTUBE_PREVIOUS","Попередня");//Previous
define("_YOUTUBE_NEXT","Наступна");//Next
define("_YOUTUBE_EXAMPLE","Приклад");//Example
?>
