<?php
define("_LINKS_LINKS","Linkek");//Links
define("_LINKS_LESSONLINK","Linkek");//Links
define("_LINKS_MODULE","Linkek modul");//Links Module
define("_LINKS_MAIN","Főoldal");//Main page
define("_LINKS_MANAGEMENT","Kezelése Linkek");//Manage Links
define("_LINKS_LINKLIST","Linkek");//Links
define("_LINKS_ADDLINK","Link hozzáadása");//Add Link
define("_LINKS_DISPLAY","Szöveg megjelenítése");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Leírás");//Description
define("_LINKS_INSERTLINK","Link hozzáadása");//Add link
define("_LINKS_NOLINKFOUND","Nem találtak kapcsolatot");//No links were found
define("_LINKS_LINKSPAGE","Linkek");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","A link került ki sikeresen");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Hiba történt, miközben behelyezte a kapcsolatot");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","A kapcsolat sikeres volt");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Hiba történt a frissítés a kapcsolatot");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","A link sikeresen törlésre került");//The link was deleted succesfully
define("_LINKS_DELETELINK","Törlés link");//Delete link
define("_LINKS_EDITLINK","Szerkesztés linkre");//Edit link
define("_LINKS_GOTOLINKSPAGE","Ugrás a linkek az oldalon");//Go to Links page
?>
