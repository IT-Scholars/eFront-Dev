<?php
define("_LINKS_LINKS","Liens");//Links
define("_LINKS_LESSONLINK","Liens");//Links
define("_LINKS_MODULE","Module Liens");//Links Module
define("_LINKS_MAIN","Page principale");//Main page
define("_LINKS_MANAGEMENT","Gérer les liens");//Manage Links

define("_LINKS_LINKLIST","Liens");//Links
define("_LINKS_ADDLINK","Ajouter un lien");//Add Link
define("_LINKS_DISPLAY","Afficher du texte");//Display text
define("_LINKS_LINK","Lien");//Link
define("_LINKS_DESCRIPTION","Description");//Description
define("_LINKS_INSERTLINK","Ajouter un lien");//Add link
define("_LINKS_NOLINKFOUND","Pas de liens ont été trouvés");//No links were found
define("_LINKS_LINKSPAGE","Liens");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Le lien a été inséré avec succès");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Un problème est survenu alors que l&#39;insertion du lien");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Le lien a été mis à jour avec succès");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Un problème est survenu alors que la mise à jour le lien");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Le lien a été supprimé avec succès");//The link was deleted succesfully
define("_LINKS_DELETELINK","Supprimer le lien");//Delete link
define("_LINKS_EDITLINK","Modifier le lien");//Edit link
define("_LINKS_GOTOLINKSPAGE","Aller à la page de liens");//Go to Links page
?>
