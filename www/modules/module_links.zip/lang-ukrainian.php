<?php
define("_LINKS_LINKS","Посилання");//Links
define("_LINKS_LESSONLINK","Посилання");//Links
define("_LINKS_MODULE","Посилання Модуль");//Links Module
define("_LINKS_MAIN","Головна");//Main page
define("_LINKS_MANAGEMENT","Управління Посилання");//Manage Links
define("_LINKS_LINKLIST","Посилання");//Links
define("_LINKS_ADDLINK","Додати посилання");//Add Link
define("_LINKS_DISPLAY","Показати текст");//Display text
define("_LINKS_LINK","Посилання");//Link
define("_LINKS_DESCRIPTION","Опис");//Description
define("_LINKS_INSERTLINK","Додати посилання");//Add link
define("_LINKS_NOLINKFOUND","Посилання не знайдені");//No links were found
define("_LINKS_LINKSPAGE","Посилання");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Посилання була вставлена успішно");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Виникла проблема при вставці посилання");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Посилання була успішно оновлені");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Виникла проблема при оновленні посилання");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Посилання була успішно видалена");//The link was deleted succesfully
define("_LINKS_DELETELINK","Видалити посилання");//Delete link
define("_LINKS_EDITLINK","Змінити посилання");//Edit link
define("_LINKS_GOTOLINKSPAGE","Перейти на сторінку Посилання");//Go to Links page
?>
