<?php
define("_LINKS_LINKS","Linkit");//Links
define("_LINKS_LESSONLINK","Linkit");//Links
define("_LINKS_MODULE","Linkit-moduuli");//Links Module
define("_LINKS_MAIN","PRH");//Main page
define("_LINKS_MANAGEMENT","Hallitse Linkit");//Manage Links

define("_LINKS_LINKLIST","Linkit");//Links
define("_LINKS_ADDLINK","Lisää linkki");//Add Link
define("_LINKS_DISPLAY","Näytön tekstit");//Display text
define("_LINKS_LINK","Linkki");//Link
define("_LINKS_DESCRIPTION","Kuvaus");//Description
define("_LINKS_INSERTLINK","Lisää linkki");//Add link
define("_LINKS_NOLINKFOUND","Ei linkkejä ei löytynyt");//No links were found
define("_LINKS_LINKSPAGE","Linkit");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Tämä linkki on lisätty onnistuneesti");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Ongelma ilmeni, kun lisäämällä linkki");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Tämä linkki on päivitetty onnistuneesti");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Ongelma ilmeni, kun taas ajan tasalle linkki");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Tämä linkki on poistettu onnistuneesti");//The link was deleted succesfully
define("_LINKS_DELETELINK","Poista linkki");//Delete link
define("_LINKS_EDITLINK","Muokkaa linkkiä");//Edit link
define("_LINKS_GOTOLINKSPAGE","Siirry Linkit sivu");//Go to Links page
?>
