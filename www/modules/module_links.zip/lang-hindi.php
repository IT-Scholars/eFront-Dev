<?php
define("_LINKS_LINKS","ΰ¤•ΰ¤΅ΰ¤Όΰ¤Ώΰ¤―ΰ¤Ύΰ¤");//Links
define("_LINKS_LESSONLINK","ΰ¤•ΰ¤΅ΰ¤Όΰ¤Ώΰ¤―ΰ¤Ύΰ¤");//Links
define("_LINKS_MODULE","ΰ¤•ΰ¤΅ΰ¤Όΰ¤Ώΰ¤―ΰ¤Ύΰ¤ ΰ¤®ΰ¥‰ΰ¤΅ΰ¥ΰ¤―ΰ¥‚ΰ¤²");//Links Module
define("_LINKS_MAIN","ΰ¤®ΰ¥ΰ¤–ΰ¥ΰ¤― ΰ¤ΰ¥ƒΰ¤·ΰ¥ΰ¤ ");//Main page
define("_LINKS_MANAGEMENT","ΰ¤ΰ¥ΰ¤°ΰ¤¬ΰ¤‚ΰ¤§ΰ¤Ώΰ¤¤ ΰ¤•ΰ¤΅ΰ¤Όΰ¤Ώΰ¤―ΰ¤Ύΰ¤");//Manage Links

define("_LINKS_LINKLIST","ΰ¤•ΰ¤΅ΰ¤Όΰ¤Ώΰ¤―ΰ¤Ύΰ¤");//Links
define("_LINKS_ADDLINK","ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¥‡ΰ¤‚");//Add Link
define("_LINKS_DISPLAY","ΰ¤ΰ¥ΰ¤°ΰ¤¦ΰ¤°ΰ¥ΰ¤¶ΰ¤¨ ΰ¤ΰ¤Ύΰ¤ ");//Display text
define("_LINKS_LINK","ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¤¨ΰ¤Ύ");//Link
define("_LINKS_DESCRIPTION","ΰ¤µΰ¤°ΰ¥ΰ¤£ΰ¤¨");//Description
define("_LINKS_INSERTLINK","ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¥‡ΰ¤‚");//Add link
define("_LINKS_NOLINKFOUND","ΰ¤•ΰ¥‹ΰ¤ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤ΰ¤Ύΰ¤ ΰ¤—ΰ¤");//No links were found
define("_LINKS_LINKSPAGE","ΰ¤•ΰ¤΅ΰ¤Όΰ¤Ώΰ¤―ΰ¤Ύΰ¤");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","ΰ¤‡ΰ¤Έ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤•ΰ¥‹ ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤΅ΰ¤Ύΰ¤²ΰ¤Ύ ΰ¤¥ΰ¤Ύ");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","ΰ¤ΰ¤¬ΰ¤•ΰ¤Ώ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤΅ΰ¤Ύΰ¤²ΰ¤¨ΰ¥‡ ΰ¤ΰ¤• ΰ¤Έΰ¤®ΰ¤Έΰ¥ΰ¤―ΰ¤Ύ ΰ¤Ήΰ¥ΰ¤");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","ΰ¤‡ΰ¤Έ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤•ΰ¥‹ ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤…ΰ¤¦ΰ¥ΰ¤―ΰ¤¤ΰ¤¨ ΰ¤•ΰ¤Ώΰ¤―ΰ¤Ύ ΰ¤—ΰ¤―ΰ¤Ύ");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","ΰ¤ΰ¤¬ΰ¤•ΰ¤Ώ ΰ¤•ΰ¤΅ΰ¤Όΰ¥€ ΰ¤•ΰ¥‹ ΰ¤…ΰ¤¦ΰ¥ΰ¤―ΰ¤¤ΰ¤¨ ΰ¤ΰ¤• ΰ¤Έΰ¤®ΰ¤Έΰ¥ΰ¤―ΰ¤Ύ ΰ¤Ήΰ¥ΰ¤");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","ΰ¤‡ΰ¤Έ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤•ΰ¥‹ ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤¨ΰ¤·ΰ¥ΰ¤ ΰ¤•ΰ¤° ΰ¤¦ΰ¤Ώΰ¤―ΰ¤Ύ ΰ¤—ΰ¤―ΰ¤Ύ");//The link was deleted succesfully
define("_LINKS_DELETELINK","ΰ¤Ήΰ¤ΰ¤Ύΰ¤ΰ¤ ΰ¤•ΰ¤΅ΰ¤Όΰ¥€");//Delete link
define("_LINKS_EDITLINK","ΰ¤Έΰ¤‚ΰ¤ΰ¤Ύΰ¤¦ΰ¤Ώΰ¤¤ ΰ¤•ΰ¤°ΰ¥‡ΰ¤‚ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•");//Edit link
define("_LINKS_GOTOLINKSPAGE","ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤•ΰ¤°ΰ¤¨ΰ¥‡ ΰ¤•ΰ¥‡ ΰ¤²ΰ¤Ώΰ¤ ΰ¤ΰ¥ƒΰ¤·ΰ¥ΰ¤  ΰ¤ΰ¤Ύΰ¤“");//Go to Links page
?>
