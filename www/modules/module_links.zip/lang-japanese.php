<?php
define("_LINKS_LINKS","リンク");//Links
define("_LINKS_LESSONLINK","リンク");//Links
define("_LINKS_MODULE","リンクモジュール");//Links Module
define("_LINKS_MAIN","メインページ");//Main page
define("_LINKS_MANAGEMENT","管理リンク");//Manage Links

define("_LINKS_LINKLIST","リンク");//Links
define("_LINKS_ADDLINK","リンクを追加");//Add Link
define("_LINKS_DISPLAY","表示テキスト");//Display text
define("_LINKS_LINK","リンク");//Link
define("_LINKS_DESCRIPTION","説明");//Description
define("_LINKS_INSERTLINK","リンクを追加");//Add link
define("_LINKS_NOLINKFOUND","リンクは見つかりませんでした");//No links were found
define("_LINKS_LINKSPAGE","リンク");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","のリンクが正常に挿入されて");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","一方、リンクを挿入するという問題が発生しました");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","のリンクが正常に更新されました");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","一方、リンクを更新するという問題が発生しました");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","のリンクが正常に削除されました");//The link was deleted succesfully
define("_LINKS_DELETELINK","削除リンク");//Delete link
define("_LINKS_EDITLINK","連係編集");//Edit link
define("_LINKS_GOTOLINKSPAGE","リンクページへ戻る");//Go to Links page
?>
