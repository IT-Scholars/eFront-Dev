<?php
define("_LINKS_LINKS","Links");//Links
define("_LINKS_LESSONLINK","Links");//Links
define("_LINKS_MODULE","Links Module");//Links Module
define("_LINKS_MAIN","Faqja kryesore");//Main page
define("_LINKS_MANAGEMENT","Manage Links");//Manage Links
define("_LINKS_LINKLIST","Links");//Links
define("_LINKS_ADDLINK","Add Link");//Add Link
define("_LINKS_DISPLAY","Display text");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Përshkrim");//Description
define("_LINKS_INSERTLINK","Add link");//Add link
define("_LINKS_NOLINKFOUND","Nuk ka lidhje janë gjetur");//No links were found
define("_LINKS_LINKSPAGE","Links");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Lidhja u futur me sukses");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Një problem ka ndodhur ndërsa futur në linkun");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Lidhja u freskua me sukses");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Një problem ka ndodhur ndërsa përditësimin Lidhje");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Lidhja u fshi me sukses");//The link was deleted succesfully
define("_LINKS_DELETELINK","Lidhje Fshije");//Delete link
define("_LINKS_EDITLINK","Edit Lidhje");//Edit link
define("_LINKS_GOTOLINKSPAGE","Shko tek faqja Links");//Go to Links page
?>
