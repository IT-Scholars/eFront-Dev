<?php
define("_LINKS_LINKS","لینک ها");//Links
define("_LINKS_LESSONLINK","لینک ها");//Links
define("_LINKS_MODULE","لینک ماژول");//Links Module
define("_LINKS_MAIN","صفحه اصلی");//Main page
define("_LINKS_MANAGEMENT","مدیریت لینک");//Manage Links
define("_LINKS_LINKLIST","لینک ها");//Links
define("_LINKS_ADDLINK","اضافه کردن لینک");//Add Link
define("_LINKS_DISPLAY","نمایش متن");//Display text
define("_LINKS_LINK","پیوند");//Link
define("_LINKS_DESCRIPTION","شرح");//Description
define("_LINKS_INSERTLINK","اضافه کردن لینک");//Add link
define("_LINKS_NOLINKFOUND","بدون لینک پیدا نشد");//No links were found
define("_LINKS_LINKSPAGE","لینک ها");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","پیوند با موفقیت وارد شد");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","مشکل رخ داده در حالی که قرار دادن لینک");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","پیوند با موفقیت به روز شد");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","مشکل رخ داده در حالی که به روز رسانی لینک");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","پیوند با موفقیت حذف شد");//The link was deleted succesfully
define("_LINKS_DELETELINK","لینک حذف");//Delete link
define("_LINKS_EDITLINK","ویرایش پیوند");//Edit link
define("_LINKS_GOTOLINKSPAGE","برو به صفحه لینک");//Go to Links page
?>
