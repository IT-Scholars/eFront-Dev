<?php
define("_LINKS_LINKS","Odkazy");//Links
define("_LINKS_LESSONLINK","Odkazy");//Links
define("_LINKS_MODULE","Odkazy Module");//Links Module
define("_LINKS_MAIN","Hlavná stránka");//Main page
define("_LINKS_MANAGEMENT","Spravovanie Odkazy");//Manage Links
define("_LINKS_LINKLIST","Odkazy");//Links
define("_LINKS_ADDLINK","Pridať odkaz");//Add Link
define("_LINKS_DISPLAY","Zobraziť text");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Popis");//Description
define("_LINKS_INSERTLINK","Pridať odkaz");//Add link
define("_LINKS_NOLINKFOUND","Žiadne odkazy boli nájdené");//No links were found
define("_LINKS_LINKSPAGE","Odkazy");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Odkaz bol úspešne vložený");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Problém nastal pri vkladaní odkazu");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Odkaz bol úspešne aktualizovaný");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Problém nastal pri aktualizácii odkazu");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Odkaz bol úspešne zmazaný");//The link was deleted succesfully
define("_LINKS_DELETELINK","Odstrániť odkaz");//Delete link
define("_LINKS_EDITLINK","Upraviť odkaz");//Edit link
define("_LINKS_GOTOLINKSPAGE","Prejsť na stránku Odkazy");//Go to Links page
?>
