<?php
define("_LINKS_LINKS","Bağlantılar");
define("_LINKS_LESSONLINK", "Bağlantılar");
define("_LINKS_MODULE", "Bağlantılar Modülü");
define("_LINKS_MAIN", "Ana Sayfa");
define("_LINKS_MANAGEMENT", "Bağlantıları Yönet");
define("_LINKS_LINKLIST", "Bağlantılar");
define("_LINKS_ADDLINK", "Bağlantı Ekle");
define("_LINKS_DISPLAY", "Başlık");
define("_LINKS_LINK", "Bağlantı");
define("_LINKS_DESCRIPTION", "Açıklama");
define("_LINKS_INSERTLINK", "Bağlantı ekle");
define("_LINKS_NOLINKFOUND", "Herhangi bir bağlantı bulunamadı");
define("_LINKS_LINKSPAGE", "Bağlantılar");
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY", "Bağlantı başarıyla eklendi");
define("_LINKS_PROBLEMINSERTINGLINKENTRY", "Bağlantı eklemesi sırasında bazı sorunlar oluştu");
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY", "Bağlantı başarıyla güncellendi");
define("_LINKS_PROBLEMUPDATINGLINKENTRY", "Bağlantı güncellemesi sırasında bazı sorunlar oluştu");
define("_LINKS_SUCCESFULLYDELETEDLINK", "Bağlantı başarıyla silindi");
define("_LINKS_DELETELINK", "Bağlantıyı sil");
define("_LINKS_EDITLINK", "Bağlantıyı düzenle");
define("_LINKS_GOTOLINKSPAGE", "Bağlantılar sayfasına git");
?>