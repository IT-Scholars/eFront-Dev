<?php
define("_LINKS_LINKS","صلات");//Links
define("_LINKS_LESSONLINK","صلات");//Links
define("_LINKS_MODULE","روابط الوحدة");//Links Module
define("_LINKS_MAIN","الصفحة الرئيسية");//Main page
define("_LINKS_MANAGEMENT","إدارة صلة");//Manage Links

define("_LINKS_LINKLIST","صلات");//Links
define("_LINKS_ADDLINK","أضف لينك");//Add Link
define("_LINKS_DISPLAY","عرض نص");//Display text
define("_LINKS_LINK","رابط");//Link
define("_LINKS_DESCRIPTION","الوصف");//Description
define("_LINKS_INSERTLINK","أضف صلة");//Add link
define("_LINKS_NOLINKFOUND","تم العثور على أي صلة");//No links were found
define("_LINKS_LINKSPAGE","صلات");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","الصلة أضيفت بنجاح");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","وهناك مشكلة وقعت بينما بإدراج صلة");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","تم تحديث الصلة بنجاح");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","وهناك مشكلة حدثت حين استكمال وصلة");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","تم حذف الصلة بنجاح");//The link was deleted succesfully
define("_LINKS_DELETELINK","حذف صلة");//Delete link
define("_LINKS_EDITLINK","وصلة تحرير");//Edit link
define("_LINKS_GOTOLINKSPAGE","اذهب إلى صفحة صلة");//Go to Links page
?>
