<?php
define("_LINKS_LINKS","Enlaces");//Links
define("_LINKS_LESSONLINK","Enlaces");//Links
define("_LINKS_MODULE","Módulo de Enlaces");//Links Module
define("_LINKS_MAIN","Página Principal");//Main page
define("_LINKS_MANAGEMENT","Administrar vínculos");//Manage Links

define("_LINKS_LINKLIST","Enlaces");//Links
define("_LINKS_ADDLINK","Añadir enlace");//Add Link
define("_LINKS_DISPLAY","Pantalla de texto");//Display text
define("_LINKS_LINK","Vínculo");//Link
define("_LINKS_DESCRIPTION","Descripción");//Description
define("_LINKS_INSERTLINK","Añadir enlace");//Add link
define("_LINKS_NOLINKFOUND","No se encontraron vínculos");//No links were found
define("_LINKS_LINKSPAGE","Enlaces");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","El vínculo se insertó con éxito");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Un problema se produjo al mismo tiempo la inserción de la relación");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","El vínculo se ha actualizado con éxito");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Se ha producido un problema mientras que la actualización de la relación");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","El vínculo se ha eliminado con éxito");//The link was deleted succesfully
define("_LINKS_DELETELINK","Eliminar vínculo");//Delete link
define("_LINKS_EDITLINK","Editar enlace");//Edit link
define("_LINKS_GOTOLINKSPAGE","Ir a la página de enlaces");//Go to Links page
?>
