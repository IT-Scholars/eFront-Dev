<?php
define("_LINKS_LINKS","Povezave");//Links
define("_LINKS_LESSONLINK","Povezave");//Links
define("_LINKS_MODULE","Povezave Module");//Links Module
define("_LINKS_MAIN","Prva stran");//Main page
define("_LINKS_MANAGEMENT","Upravljanje Povezave");//Manage Links
define("_LINKS_LINKLIST","Povezave");//Links
define("_LINKS_ADDLINK","Dodaj povezavo");//Add Link
define("_LINKS_DISPLAY","Prikaz besedila");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Opis");//Description
define("_LINKS_INSERTLINK","Dodaj povezavo");//Add link
define("_LINKS_NOLINKFOUND","Št povezav je bilo ugotovljeno,");//No links were found
define("_LINKS_LINKSPAGE","Povezave");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Ta povezava je bila uspešno vstavljena");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Težava pri vstavite povezavo");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Link je bil uspešno posodobljen");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Težava pri posodabljanju povezave");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Ta povezava je bila uspešno izbrisana");//The link was deleted succesfully
define("_LINKS_DELETELINK","Izbriši povezavo");//Delete link
define("_LINKS_EDITLINK","Uredi povezavo");//Edit link
define("_LINKS_GOTOLINKSPAGE","Pojdi na stran Povezave");//Go to Links page
?>
