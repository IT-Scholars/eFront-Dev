<?php
define("_LINKS_LINKS","Links");//Links
define("_LINKS_LESSONLINK","Links");//Links
define("_LINKS_MODULE","Módulo Links");//Links Module
define("_LINKS_MAIN","Página principal");//Main page
define("_LINKS_MANAGEMENT","Gerenciar Links");//Manage Links

define("_LINKS_LINKLIST","Links");//Links
define("_LINKS_ADDLINK","Adicionar link");//Add Link
define("_LINKS_DISPLAY","Mostrar texto");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Descrição");//Description
define("_LINKS_INSERTLINK","Adicionar link");//Add link
define("_LINKS_NOLINKFOUND","Nenhum link foi encontrado");//No links were found
define("_LINKS_LINKSPAGE","Links");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","O link foi inserido com sucesso");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Um problema ocorreu ao inserir o link");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","O link foi atualizado com sucesso");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Um problema ocorreu ao atualizar o link");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","O link foi excluido com sucesso");//The link was deleted succesfully
define("_LINKS_DELETELINK","Excluir link");//Delete link
define("_LINKS_EDITLINK","Editar link");//Edit link
define("_LINKS_GOTOLINKSPAGE","Ir à página Links");//Go to Links page
?>
