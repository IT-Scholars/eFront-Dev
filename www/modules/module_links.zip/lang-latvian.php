<?php
define("_LINKS_LINKS","Saites");//Links
define("_LINKS_LESSONLINK","Saites");//Links
define("_LINKS_MODULE","Saites modulis");//Links Module
define("_LINKS_MAIN","Galvenā lapa");//Main page
define("_LINKS_MANAGEMENT","Pārvaldīt Saites");//Manage Links
define("_LINKS_LINKLIST","Saites");//Links
define("_LINKS_ADDLINK","Pievienot saiti");//Add Link
define("_LINKS_DISPLAY","Displeja tekstu");//Display text
define("_LINKS_LINK","Saites");//Link
define("_LINKS_DESCRIPTION","Apraksts");//Description
define("_LINKS_INSERTLINK","Pievienot saiti");//Add link
define("_LINKS_NOLINKFOUND","Nekādas saiknes tika atrasti");//No links were found
define("_LINKS_LINKSPAGE","Saites");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Saikne tika iekļauts veiksmīgi");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Problēma radās, ievietojot saiti");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Saikne veiksmīgi atjaunināts");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Radās problēma, kamēr atjaunināt saites");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Saikne veiksmīgi izdzēsts");//The link was deleted succesfully
define("_LINKS_DELETELINK","Dzēst saiti");//Delete link
define("_LINKS_EDITLINK","Saites rediģēt");//Edit link
define("_LINKS_GOTOLINKSPAGE","Doties uz saites lappusi");//Go to Links page
?>
