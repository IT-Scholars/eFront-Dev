<?php
define("_LINKS_LINKS","링크");//Links
define("_LINKS_LESSONLINK","링크");//Links
define("_LINKS_MODULE","링크 모듈");//Links Module
define("_LINKS_MAIN","메인 페이지");//Main page
define("_LINKS_MANAGEMENT","링크 관리");//Manage Links
define("_LINKS_LINKLIST","링크");//Links
define("_LINKS_ADDLINK","링크 추가");//Add Link
define("_LINKS_DISPLAY","문자");//Display text
define("_LINKS_LINK","링크");//Link
define("_LINKS_DESCRIPTION","설명");//Description
define("_LINKS_INSERTLINK","링크 추가");//Add link
define("_LINKS_NOLINKFOUND","아니 링크를 찾을 수 없습니다");//No links were found
define("_LINKS_LINKSPAGE","링크");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","링크가 성공적으로 삽입했습니다");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","링크를 삽입하는 동안 문제가 발생했습니다");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","링크가 성공적으로 업데이 트되었습니다");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","링크를 업데이 트하는 동안 문제가 발생했습니다");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","연결이 성공적으로 삭제되었습니다");//The link was deleted succesfully
define("_LINKS_DELETELINK","삭제 링크");//Delete link
define("_LINKS_EDITLINK","링크 편집");//Edit link
define("_LINKS_GOTOLINKSPAGE","링크 페이지로 이동");//Go to Links page
?>
