<?php
define("_LINKS_LINKS","Odkazy");//Links
define("_LINKS_LESSONLINK","Odkazy");//Links
define("_LINKS_MODULE","Odkazy Modul");//Links Module
define("_LINKS_MAIN","Hlavní stránka");//Main page
define("_LINKS_MANAGEMENT","Správa odkazů");//Manage Links

define("_LINKS_LINKLIST","Odkazy");//Links
define("_LINKS_ADDLINK","Add Link");//Add Link
define("_LINKS_DISPLAY","Zobrazit text");//Display text
define("_LINKS_LINK","Odkaz");//Link
define("_LINKS_DESCRIPTION","Popis");//Description
define("_LINKS_INSERTLINK","Přidat odkaz");//Add link
define("_LINKS_NOLINKFOUND","Žádné odkazy nebyly nalezeny");//No links were found
define("_LINKS_LINKSPAGE","Odkazy");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Tento odkaz byl úspěšně vložen");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","A problém nastal, zatímco vložení odkazu");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Tento odkaz byl úspěšně aktualizován");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","A problém nastal, zatímco aktualizaci odkaz");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Tento odkaz byl úspěšně smazán");//The link was deleted succesfully
define("_LINKS_DELETELINK","Odstranit odkaz");//Delete link
define("_LINKS_EDITLINK","Upravit odkaz");//Edit link
define("_LINKS_GOTOLINKSPAGE","Jdi na stránku Odkazy");//Go to Links page
?>
