<?php
define("_LINKS_LINKS","Links");//Links
define("_LINKS_LESSONLINK","Links");//Links
define("_LINKS_MODULE","Links Module");//Links Module
define("_LINKS_MAIN","Pangunahing pahina");//Main page
define("_LINKS_MANAGEMENT","Pamahalaan ang mga Links");//Manage Links
define("_LINKS_LINKLIST","Links");//Links
define("_LINKS_ADDLINK","Magdagdag ng Link");//Add Link
define("_LINKS_DISPLAY","Ipakita ang mga text");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Paglalarawan");//Description
define("_LINKS_INSERTLINK","Magdagdag ng link");//Add link
define("_LINKS_NOLINKFOUND","Walang mga link ay natagpuan");//No links were found
define("_LINKS_LINKSPAGE","Links");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Ang link ay nakapasok matagumpay");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","problemang naganap habang ang pagpasok ng mga link");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Ang link ay na-update matagumpay");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","problemang naganap habang ina-update ang mga link");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Ang link ay matagumpay na tinanggal");//The link was deleted succesfully
define("_LINKS_DELETELINK","Tanggalin ang link");//Delete link
define("_LINKS_EDITLINK","I-edit ang link");//Edit link
define("_LINKS_GOTOLINKSPAGE","Pumunta sa pahina Links");//Go to Links page
?>
