<?php
define("_LINKS_LINKS","Enllaços");//Links
define("_LINKS_LESSONLINK","Enllaços");//Links
define("_LINKS_MODULE","Mòdul d&#39;Enllaços");//Links Module
define("_LINKS_MAIN","Pàgina principal");//Main page
define("_LINKS_MANAGEMENT","Administrar Enllaços");//Manage Links
define("_LINKS_LINKLIST","Enllaços");//Links
define("_LINKS_ADDLINK","Afegeix enllaç");//Add Link
define("_LINKS_DISPLAY","Pantalla de text");//Display text
define("_LINKS_LINK","Enllaç");//Link
define("_LINKS_DESCRIPTION","Descripció");//Description
define("_LINKS_INSERTLINK","Afegeix enllaç");//Add link
define("_LINKS_NOLINKFOUND","No hi ha enllaços es troben");//No links were found
define("_LINKS_LINKSPAGE","Enllaços");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","L&#39;enllaç es va inserir amb èxit");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Ha hagut un problema en inserir l&#39;enllaç");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","L&#39;enllaç s&#39;ha actualitzat correctament");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Es va produir un problema en actualitzar el vincle");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","El vincle s&#39;ha eliminat amb èxit");//The link was deleted succesfully
define("_LINKS_DELETELINK","enllaç Eliminar");//Delete link
define("_LINKS_EDITLINK","Enllaç Edita");//Edit link
define("_LINKS_GOTOLINKSPAGE","Anar a la pàgina d&#39;enllaços");//Go to Links page
?>
