<?php
define("_LINKS_LINKS","Links");//Links
define("_LINKS_LESSONLINK","Links");//Links
define("_LINKS_MODULE","Links Module");//Links Module
define("_LINKS_MAIN","Hoofd pagina");//Main page
define("_LINKS_MANAGEMENT","Manage Links");//Manage Links

define("_LINKS_LINKLIST","Links");//Links
define("_LINKS_ADDLINK","Link toevoegen");//Add Link
define("_LINKS_DISPLAY","Weerg.tekst");//Display text
define("_LINKS_LINK","Koppelen");//Link
define("_LINKS_DESCRIPTION","Beschrijving");//Description
define("_LINKS_INSERTLINK","Voeg een link toe");//Add link
define("_LINKS_NOLINKFOUND","Geen links gevonden");//No links were found
define("_LINKS_LINKSPAGE","Links");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","De link was geplaatst met succes");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Een probleem opgetreden tijdens het plaatsen van de link");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","De link is bijgewerkt met succes");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Een probleem opgetreden tijdens het bijwerken van de link");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","De band was succesvol verwijderd");//The link was deleted succesfully
define("_LINKS_DELETELINK","Koppeling Verwijderen");//Delete link
define("_LINKS_EDITLINK","Koppeling Bewerken");//Edit link
define("_LINKS_GOTOLINKSPAGE","Ga naar Links pagina");//Go to Links page
?>
