<?php
define("_LINKS_LINKS","Links");//Links
define("_LINKS_LESSONLINK","Links");//Links
define("_LINKS_MODULE","Links-Modul");//Links Module
define("_LINKS_MAIN","Startseite");//Main page
define("_LINKS_MANAGEMENT","Links verwalten");//Manage Links

define("_LINKS_LINKLIST","Links");//Links
define("_LINKS_ADDLINK","Link hinzufügen");//Add Link
define("_LINKS_DISPLAY","Display-Text");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Beschreibung");//Description
define("_LINKS_INSERTLINK","Link hinzufügen");//Add link
define("_LINKS_NOLINKFOUND","Keine Links gefunden");//No links were found
define("_LINKS_LINKSPAGE","Links");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Der Link wurde erfolgreich eingefügt");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Beim Einsetzen des Links trat ein Problem auf");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Der Link wurde erfolgreich aktualisiert");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Beim Aktualisieren des Links trat ein Problem auf");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Der Link wurde erfolgreich gelöscht");//The link was deleted succesfully
define("_LINKS_DELETELINK","Link löschen");//Delete link
define("_LINKS_EDITLINK","Link bearbeiten");//Edit link
define("_LINKS_GOTOLINKSPAGE","Gehe zu Links-Seite");//Go to Links page
?>
