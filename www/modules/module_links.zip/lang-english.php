<?php
define("_LINKS_LINKS","Links");
define("_LINKS_LESSONLINK", "Links");
define("_LINKS_MODULE", "Links Module");
define("_LINKS_MAIN", "Main page");
define("_LINKS_MANAGEMENT", "Manage Links");
define("_LINKS_LINKLIST", "Links");
define("_LINKS_ADDLINK", "Add Link");
define("_LINKS_DISPLAY", "Display text");
define("_LINKS_LINK", "Link");
define("_LINKS_DESCRIPTION", "Description");
define("_LINKS_INSERTLINK", "Add link");
define("_LINKS_NOLINKFOUND", "No links were found");
define("_LINKS_LINKSPAGE", "Links");
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY", "The link was inserted succesfully");
define("_LINKS_PROBLEMINSERTINGLINKENTRY", "A problem occured while inserting the link");
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY", "The link was updated succesfully");
define("_LINKS_PROBLEMUPDATINGLINKENTRY", "A problem occured while updating the link");
define("_LINKS_SUCCESFULLYDELETEDLINK", "The link was deleted succesfully");
define("_LINKS_DELETELINK", "Delete link");
define("_LINKS_EDITLINK", "Edit link");
define("_LINKS_GOTOLINKSPAGE", "Go to Links page");
?>