<?php
define("_LINKS_LINKS","Länkar");//Links
define("_LINKS_LESSONLINK","Länkar");//Links
define("_LINKS_MODULE","Länkar Modul");//Links Module
define("_LINKS_MAIN","Startsida");//Main page
define("_LINKS_MANAGEMENT","Manage Links");//Manage Links

define("_LINKS_LINKLIST","Länkar");//Links
define("_LINKS_ADDLINK","Lägg till länk");//Add Link
define("_LINKS_DISPLAY","Visa text");//Display text
define("_LINKS_LINK","Länk");//Link
define("_LINKS_DESCRIPTION","Beskrivning");//Description
define("_LINKS_INSERTLINK","Lägg till länk");//Add link
define("_LINKS_NOLINKFOUND","Inga länkar hittades");//No links were found
define("_LINKS_LINKSPAGE","Länkar");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Sambandet var införas framgångsrikt");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Ett problem uppstod när du sätter på länken");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Länken uppdaterades framgångsrikt");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Ett problem uppstod när en uppdatering av länken");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Länken har tagits bort");//The link was deleted succesfully
define("_LINKS_DELETELINK","Ta bort länk");//Delete link
define("_LINKS_EDITLINK","Redigera länk");//Edit link
define("_LINKS_GOTOLINKSPAGE","Gå till länksidan");//Go to Links page
?>
