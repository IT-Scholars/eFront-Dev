<?php
define("_LINKS_LINKS","链接");//Links
define("_LINKS_LESSONLINK","链接");//Links
define("_LINKS_MODULE","链接模块");//Links Module
define("_LINKS_MAIN","主网页");//Main page
define("_LINKS_MANAGEMENT","管理链接");//Manage Links

define("_LINKS_LINKLIST","链接");//Links
define("_LINKS_ADDLINK","添加链接");//Add Link
define("_LINKS_DISPLAY","显示文字");//Display text
define("_LINKS_LINK","链接");//Link
define("_LINKS_DESCRIPTION","说明");//Description
define("_LINKS_INSERTLINK","添加链接");//Add link
define("_LINKS_NOLINKFOUND","没有联系被发现");//No links were found
define("_LINKS_LINKSPAGE","链接");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","链接插入成功");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","出现了问题，而插入链接");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","连结已更新成功");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","出现了问题，而更新的链接");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","这个链接被删除成功");//The link was deleted succesfully
define("_LINKS_DELETELINK","删除链接");//Delete link
define("_LINKS_EDITLINK","修改链接");//Edit link
define("_LINKS_GOTOLINKSPAGE","进入链接页面");//Go to Links page
?>
