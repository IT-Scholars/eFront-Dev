<?php
define("_LINKS_LINKS","Links");//Links
define("_LINKS_LESSONLINK","Links");//Links
define("_LINKS_MODULE","Modulo Collegamenti");//Links Module
define("_LINKS_MAIN","Pagina principale");//Main page
define("_LINKS_MANAGEMENT","Gestisci Links");//Manage Links

define("_LINKS_LINKLIST","Links");//Links
define("_LINKS_ADDLINK","Aggiungi un sito");//Add Link
define("_LINKS_DISPLAY","Visualizzare testo");//Display text
define("_LINKS_LINK","Collegamento");//Link
define("_LINKS_DESCRIPTION","Descrizione");//Description
define("_LINKS_INSERTLINK","Aggiungi link");//Add link
define("_LINKS_NOLINKFOUND","Nessun link sono stati trovati");//No links were found
define("_LINKS_LINKSPAGE","Links");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Il collegamento è stato inserito con successo");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Un problema si è verificato mentre inserendo il link");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Il link è stato aggiornato con successo");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Un problema si è verificato durante l&#39;aggiornamento il link");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Il link è stato eliminato con successo");//The link was deleted succesfully
define("_LINKS_DELETELINK","Elimina collegamento");//Delete link
define("_LINKS_EDITLINK","Link Modifica");//Edit link
define("_LINKS_GOTOLINKSPAGE","Vai alla pagina dei link");//Go to Links page
?>
