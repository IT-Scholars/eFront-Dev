<?php
define("_LINKS_LINKS","Ligazóns");//Links
define("_LINKS_LESSONLINK","Ligazóns");//Links
define("_LINKS_MODULE","Ligazóns Módulo");//Links Module
define("_LINKS_MAIN","Páxina Principal");//Main page
define("_LINKS_MANAGEMENT","Administrar Ligazóns");//Manage Links
define("_LINKS_LINKLIST","Ligazóns");//Links
define("_LINKS_ADDLINK","Engadir Enlace");//Add Link
define("_LINKS_DISPLAY","Amosar texto");//Display text
define("_LINKS_LINK","Enlace");//Link
define("_LINKS_DESCRIPTION","Descrición");//Description
define("_LINKS_INSERTLINK","Engadir ligazón");//Add link
define("_LINKS_NOLINKFOUND","Non hai enlaces se atoparon");//No links were found
define("_LINKS_LINKSPAGE","Ligazóns");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","A ligazón foi inserido con éxito");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Houbo un problema ao engadir a ligazón");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","A ligazón foi actualizado correctamente");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Houbo un problema a actualización do enlace");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","A ligazón foi borrado con éxito");//The link was deleted succesfully
define("_LINKS_DELETELINK","enlace Eliminar");//Delete link
define("_LINKS_EDITLINK","Enlace Editar");//Edit link
define("_LINKS_GOTOLINKSPAGE","Ir á páxina de enlaces");//Go to Links page
?>
