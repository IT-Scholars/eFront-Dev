<?php
define("_LINKS_LINKS","Linker");//Links
define("_LINKS_LESSONLINK","Linker");//Links
define("_LINKS_MODULE","Lenker Modul");//Links Module
define("_LINKS_MAIN","Hovedside");//Main page
define("_LINKS_MANAGEMENT","Behandle Links");//Manage Links

define("_LINKS_LINKLIST","Linker");//Links
define("_LINKS_ADDLINK","Legg til Link");//Add Link
define("_LINKS_DISPLAY","Vis tekst");//Display text
define("_LINKS_LINK","Forbindelse");//Link
define("_LINKS_DESCRIPTION","Beskrivelse");//Description
define("_LINKS_INSERTLINK","Legg til lenke");//Add link
define("_LINKS_NOLINKFOUND","Ingen lenker ble funnet");//No links were found
define("_LINKS_LINKSPAGE","Linker");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Koblingen ble satt inn vellykket");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Et problem oppstod ved å sette inn lenke");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Koblingen ble oppdatert");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Et problem oppstod under oppdaterer koblingen");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Koblingen ble slettet");//The link was deleted succesfully
define("_LINKS_DELETELINK","Slett kobling");//Delete link
define("_LINKS_EDITLINK","Rediger lenke");//Edit link
define("_LINKS_GOTOLINKSPAGE","Gå til side Links");//Go to Links page
?>
