<?php
define("_LINKS_LINKS","Linki");//Links
define("_LINKS_LESSONLINK","Linki");//Links
define("_LINKS_MODULE","Linki Moduł");//Links Module
define("_LINKS_MAIN","Strona główna");//Main page
define("_LINKS_MANAGEMENT","Zarządzanie Linki");//Manage Links

define("_LINKS_LINKLIST","Linki");//Links
define("_LINKS_ADDLINK","Dodaj Link");//Add Link
define("_LINKS_DISPLAY","Wyświetlacz tekstowy");//Display text
define("_LINKS_LINK","Łącze");//Link
define("_LINKS_DESCRIPTION","Opis");//Description
define("_LINKS_INSERTLINK","Dodaj link");//Add link
define("_LINKS_NOLINKFOUND","Nie znaleziono linków");//No links were found
define("_LINKS_LINKSPAGE","Linki");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Link został dodany pomyślnie");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Wystąpił problem podczas wkładania link");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Link został zaktualizowany");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Wystąpił problem podczas aktualizacji link");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Link został usunięty z powodzeniem");//The link was deleted succesfully
define("_LINKS_DELETELINK","Usuń link");//Delete link
define("_LINKS_EDITLINK","Edytuj link");//Edit link
define("_LINKS_GOTOLINKSPAGE","Przejdź do strony Linki");//Go to Links page
?>
