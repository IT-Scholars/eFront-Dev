<?php
define("_LINKS_LINKS","Ссылки");//Links
define("_LINKS_LESSONLINK","Ссылки");//Links
define("_LINKS_MODULE","Ссылки модуль");//Links Module
define("_LINKS_MAIN","Главная страница");//Main page
define("_LINKS_MANAGEMENT","Управление Ссылки");//Manage Links

define("_LINKS_LINKLIST","Ссылки");//Links
define("_LINKS_ADDLINK","Добавить ссылку");//Add Link
define("_LINKS_DISPLAY","Показать текст");//Display text
define("_LINKS_LINK","Ссылка");//Link
define("_LINKS_DESCRIPTION","Описание");//Description
define("_LINKS_INSERTLINK","Добавить ссылку");//Add link
define("_LINKS_NOLINKFOUND","Нет ссылки были найдены");//No links were found
define("_LINKS_LINKSPAGE","Ссылки");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Ссылка была вставлена успешно");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Проблема произошла в то время как вставить ссылку");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Связь была успешно обновлен");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Проблема возникла при обновлении связь");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Связь была успешно удалена");//The link was deleted succesfully
define("_LINKS_DELETELINK","Удалить ссылку");//Delete link
define("_LINKS_EDITLINK","Изменить ссылку");//Edit link
define("_LINKS_GOTOLINKSPAGE","Перейти на страницу ссылок");//Go to Links page
?>
