<?php
define("_LINKS_LINKS", "Tautan");//Links
define("_LINKS_LESSONLINK", "Tautan");//Links
define("_LINKS_MODULE", "Modul Tautan");//Links Module
define("_LINKS_MAIN", "Halaman utama");//Main page
define("_LINKS_MANAGEMENT", "Kelola Tautan");//Manage Links
define("_LINKS_LINKLIST", "Tautan");//Links
define("_LINKS_ADDLINK", "Tambahkan Tautan");//Add Link
define("_LINKS_DISPLAY", "Tampilkan teks");//Display text
define("_LINKS_LINK", "Tautan");//Link
define("_LINKS_DESCRIPTION", "Deskripsi");//Description
define("_LINKS_INSERTLINK", "Tambahkan tautan");//Add link
define("_LINKS_NOLINKFOUND", "Tidak ada tautan yang ditemukan");//No links were found
define("_LINKS_LINKSPAGE", "Tautan");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY", "Tautan tersebut berhasil disisipkan");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY", "Terjadi masalah saat menyisipkan tautan");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY", "Tautan berhasil diperbaharui");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY", "Terjadi masalah saat memperbarui tautan");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK", "Tautan berhasil dihapus");//The link was deleted succesfully
define("_LINKS_DELETELINK", "Hapus tautan");//Delete link
define("_LINKS_EDITLINK", "Sunting tautan");//Edit link
define("_LINKS_GOTOLINKSPAGE", "Menuju ke halaman Tautan");//Go to Links page
?>