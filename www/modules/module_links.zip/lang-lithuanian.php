<?php
define("_LINKS_LINKS","Nuorodos");//Links
define("_LINKS_LESSONLINK","Nuorodos");//Links
define("_LINKS_MODULE","Nuorodos modulis");//Links Module
define("_LINKS_MAIN","Pagrindinis puslapis");//Main page
define("_LINKS_MANAGEMENT","Valdymas Nuorodos");//Manage Links
define("_LINKS_LINKLIST","Nuorodos");//Links
define("_LINKS_ADDLINK","Pridėti nuorodą");//Add Link
define("_LINKS_DISPLAY","Rodyti tekstą");//Display text
define("_LINKS_LINK","Nuoroda");//Link
define("_LINKS_DESCRIPTION","Aprašymas");//Description
define("_LINKS_INSERTLINK","Pridėti nuorodą");//Add link
define("_LINKS_NOLINKFOUND","Nėra nuorodų nerasta");//No links were found
define("_LINKS_LINKSPAGE","Nuorodos");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Nuoroda buvo įtrauktas sėkmingai");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Problema atsirado tuo pačiu metu įterpiant nuorodą");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Ryšys buvo sėkmingai atnaujintas");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Iškilo problema, o atnaujinimo nuorodą");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Ryšys buvo sėkmingai ištrintas");//The link was deleted succesfully
define("_LINKS_DELETELINK","Trinti nuorodą");//Delete link
define("_LINKS_EDITLINK","Redaguoti nuorodą");//Edit link
define("_LINKS_GOTOLINKSPAGE","Grįžti į Nuorodos puslapis");//Go to Links page
?>
