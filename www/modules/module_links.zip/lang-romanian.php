<?php
define("_LINKS_LINKS","Link-uri");//Links
define("_LINKS_LESSONLINK","Link-uri");//Links
define("_LINKS_MODULE","Modul de Link-uri");//Links Module
define("_LINKS_MAIN","Pagina principală");//Main page
define("_LINKS_MANAGEMENT","Admin Link-uri");//Manage Links

define("_LINKS_LINKLIST","Link-uri");//Links
define("_LINKS_ADDLINK","Adauga Link");//Add Link
define("_LINKS_DISPLAY","Afişare text");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Descriere");//Description
define("_LINKS_INSERTLINK","Adauga link-ul de");//Add link
define("_LINKS_NOLINKFOUND","Nu au fost găsite link-uri");//No links were found
define("_LINKS_LINKSPAGE","Link-uri");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Link-ul a fost introdus cu succes");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","O problemă a apărut în timp ce introducerea pe link-ul de");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Link-ul a fost actualizat cu succes");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","O problemă a apărut în timp ce actualizarea pe link-ul de");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Link-ul a fost şters cu succes");//The link was deleted succesfully
define("_LINKS_DELETELINK","Ştergere leagă aici");//Delete link
define("_LINKS_EDITLINK","Editare legătură");//Edit link
define("_LINKS_GOTOLINKSPAGE","Du-te la pagina Link-uri");//Go to Links page
?>
