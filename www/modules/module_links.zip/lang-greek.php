<?php
define("_LINKS_LINKS","Σύνδεσμοι");
define("_LINKS_LESSONLINK", "Σύνδεσμοι");
define("_LINKS_MODULE", "Άρθρωμα Σύνδεσμοι");
define("_LINKS_MAIN","Κύρια σελίδα");
define("_LINKS_MANAGEMENT","Διαχείριση");
define("_LINKS_LINKLIST", "Σύνδεσμοι");
define("_LINKS_ADDLINK", "Προσθήκη Συνδέσμου");
define("_LINKS_DISPLAY", "Κείμενο συνδέσμου");
define("_LINKS_LINK", "Σύνδεσμος");
define("_LINKS_DESCRIPTION", "Περιγραφή");
define("_LINKS_INSERTLINK", "Προσθήκη συνδέσμου");
define("_LINKS_NOLINKFOUND", "Δεν υπάρχουν σύνδεσμοι");
define("_LINKS_LINKSPAGE", "Σύνδεσμοι");
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY", "Ο σύνδεσμος προστέθηκε επιτυχώς");
define("_LINKS_PROBLEMINSERTINGLINKENTRY", "Παρουσιάστηκε σφάλμα κατά την προσθήκη του συνδέσμου");
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY", "Ο σύνδεσμος ενημερώθηκε επιτυχώς");
define("_LINKS_PROBLEMUPDATINGLINKENTRY", "Παρουσιάστηκε σφάλμα κατά την ενημέρωση του συνδέσμου");
define("_LINKS_SUCCESFULLYDELETEDLINK", "Ο σύνδεσμος διαγράφηκε επιτυχώς");
define("_LINKS_DELETELINK", "Διαγραφή συνδέσμου");
define("_LINKS_EDITLINK", "Ενημέρωση συνδέσμου");
define("_LINKS_GOTOLINKSPAGE", "Μετάβαση στην σελίδα των Συνδέσμων");
?>