<?php
define("_LINKS_LINKS","Връзки");//Links
define("_LINKS_LESSONLINK","Връзки");//Links
define("_LINKS_MODULE","Връзки Модул");//Links Module
define("_LINKS_MAIN","Основна страница");//Main page
define("_LINKS_MANAGEMENT","Управлявайте Връзки");//Manage Links

define("_LINKS_LINKLIST","Връзки");//Links
define("_LINKS_ADDLINK","Добави Линк");//Add Link
define("_LINKS_DISPLAY","Показване на текст");//Display text
define("_LINKS_LINK","Връзка");//Link
define("_LINKS_DESCRIPTION","Описание");//Description
define("_LINKS_INSERTLINK","Добави линк");//Add link
define("_LINKS_NOLINKFOUND","Не са открити връзки");//No links were found
define("_LINKS_LINKSPAGE","Връзки");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Връзката се добавя успешно");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Проблем при включването на връзката");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Връзката е актуализиран успешно");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Проблем при актуализирането на връзката");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Връзката е изтрит успешно");//The link was deleted succesfully
define("_LINKS_DELETELINK","Изтриване на връзка");//Delete link
define("_LINKS_EDITLINK","Редактиране на връзка");//Edit link
define("_LINKS_GOTOLINKSPAGE","Отиди на страница Връзки");//Go to Links page
?>
