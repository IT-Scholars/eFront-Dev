<?php
define("_LINKS_LINKS","Liên kết");//Links
define("_LINKS_LESSONLINK","Liên kết");//Links
define("_LINKS_MODULE","Liên kết Module");//Links Module
define("_LINKS_MAIN","Trang chính");//Main page
define("_LINKS_MANAGEMENT","Quản lý Liên kết");//Manage Links
define("_LINKS_LINKLIST","Liên kết");//Links
define("_LINKS_ADDLINK","Thêm Liên kết");//Add Link
define("_LINKS_DISPLAY","Hiển thị văn bản");//Display text
define("_LINKS_LINK","Liên kết");//Link
define("_LINKS_DESCRIPTION","Mô tả");//Description
define("_LINKS_INSERTLINK","Thêm liên kết");//Add link
define("_LINKS_NOLINKFOUND","Không liên kết đã được tìm thấy");//No links were found
define("_LINKS_LINKSPAGE","Liên kết");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","liên kết này được đưa thành công");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Một vấn đề xảy ra trong khi chèn liên kết");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","liên kết này được cập nhật thành công");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Một vấn đề xảy ra khi cập nhật liên kết");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","liên kết đã được xóa thành công");//The link was deleted succesfully
define("_LINKS_DELETELINK","Xoá liên kết");//Delete link
define("_LINKS_EDITLINK","Liên kết Chỉnh sửa");//Edit link
define("_LINKS_GOTOLINKSPAGE","Tới trang Liên kết");//Go to Links page
?>
