<?php
define("_LINKS_LINKS","ลิ้งค์");//Links
define("_LINKS_LESSONLINK","ลิ้งค์");//Links
define("_LINKS_MODULE","Module Links");//Links Module
define("_LINKS_MAIN","หน้าหลัก");//Main page
define("_LINKS_MANAGEMENT","จัดการลิงก์");//Manage Links
define("_LINKS_LINKLIST","ลิ้งค์");//Links
define("_LINKS_ADDLINK","เพิ่มลิ้งค์");//Add Link
define("_LINKS_DISPLAY","แสดงข้อความ");//Display text
define("_LINKS_LINK","ลิงก์");//Link
define("_LINKS_DESCRIPTION","ลักษณะ");//Description
define("_LINKS_INSERTLINK","เพิ่มลิงค์");//Add link
define("_LINKS_NOLINKFOUND","ไม่พบการเชื่อมโยง");//No links were found
define("_LINKS_LINKSPAGE","ลิ้งค์");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","ลิงค์ถูกแทรกประสบความสำเร็จ");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","ปัญหาที่เกิดขึ้นในขณะที่การแทรกการเชื่อมโยง");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","การเชื่อมโยงได้รับการปรับปรุงเรียบร้อยแล้ว");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","ปัญหาที่เกิดขึ้นในขณะที่การปรับปรุงการเชื่อมโยง");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","ลิงค์ถูกลบแล้ว");//The link was deleted succesfully
define("_LINKS_DELETELINK","ลิงค์ลบ");//Delete link
define("_LINKS_EDITLINK","ลิงค์แก้ไข");//Edit link
define("_LINKS_GOTOLINKSPAGE","ไปที่หน้าลิงค์");//Go to Links page
?>
