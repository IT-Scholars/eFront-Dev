<?php
define("_LINKS_LINKS","קישורים");//Links
define("_LINKS_LESSONLINK","קישורים");//Links
define("_LINKS_MODULE","קישורים מודול");//Links Module
define("_LINKS_MAIN","עמוד ראשי");//Main page
define("_LINKS_MANAGEMENT","ניהול קישורים");//Manage Links
define("_LINKS_LINKLIST","קישורים");//Links
define("_LINKS_ADDLINK","הוסף קישור");//Add Link
define("_LINKS_DISPLAY","הצגת טקסט");//Display text
define("_LINKS_LINK","קישור");//Link
define("_LINKS_DESCRIPTION","תיאור");//Description
define("_LINKS_INSERTLINK","הוסף קישור");//Add link
define("_LINKS_NOLINKFOUND","קישורים לא נמצאו");//No links were found
define("_LINKS_LINKSPAGE","קישורים");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","הקישור היה מוכנס בהצלחה");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","הבעיה התרחשה בעת הוספת קישור");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","הקישור היה עודכנו בהצלחה");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","ארעה שגיאה בזמן עדכון הקישור");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","הקישור נמחק בהצלחה");//The link was deleted succesfully
define("_LINKS_DELETELINK","מחיקת הקישור");//Delete link
define("_LINKS_EDITLINK","הקישור ערוך");//Edit link
define("_LINKS_GOTOLINKSPAGE","עבור אל הדף קישורים");//Go to Links page
?>
