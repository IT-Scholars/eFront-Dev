<?php
define("_LINKS_LINKS","Линкови");//Links
define("_LINKS_LESSONLINK","Линкови");//Links
define("_LINKS_MODULE","Модул линкови");//Links Module
define("_LINKS_MAIN","Главна страна");//Main page
define("_LINKS_MANAGEMENT","Управљање Линкови");//Manage Links
define("_LINKS_LINKLIST","Линкови");//Links
define("_LINKS_ADDLINK","Додај линк");//Add Link
define("_LINKS_DISPLAY","Приказ текста");//Display text
define("_LINKS_LINK","Линк");//Link
define("_LINKS_DESCRIPTION","Опис");//Description
define("_LINKS_INSERTLINK","Додај линк");//Add link
define("_LINKS_NOLINKFOUND","Нема везе су пронађени");//No links were found
define("_LINKS_LINKSPAGE","Линкови");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Линк је успешно убачена");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Проблем се десио током уметања везу");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Линк је успешно ажуриран");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Проблем се десио током ажурирања везу");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Линк је успешно обрисан");//The link was deleted succesfully
define("_LINKS_DELETELINK","Избриши везу");//Delete link
define("_LINKS_EDITLINK","Уреди везу");//Edit link
define("_LINKS_GOTOLINKSPAGE","Иди на страницу Линкови");//Go to Links page
?>
