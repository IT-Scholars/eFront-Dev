<?php
define("_LINKS_LINKS","Links");//Links
define("_LINKS_LESSONLINK","Links");//Links
define("_LINKS_MODULE","Links Module");//Links Module
define("_LINKS_MAIN","Main page");//Main page
define("_LINKS_MANAGEMENT","Administrer Links");//Manage Links

define("_LINKS_LINKLIST","Links");//Links
define("_LINKS_ADDLINK","Tilføj Link");//Add Link
define("_LINKS_DISPLAY","Display tekst");//Display text
define("_LINKS_LINK","Link");//Link
define("_LINKS_DESCRIPTION","Beskrivelse");//Description
define("_LINKS_INSERTLINK","Tilføj link");//Add link
define("_LINKS_NOLINKFOUND","Nr. links blev ikke fundet");//No links were found
define("_LINKS_LINKSPAGE","Links");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","Forbindelsen blev indsat med succes");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","Et problem opstod under indsætte linket");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","Forbindelsen blev opdateret med succes");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","Et problem opstod under ajourføring linket");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","Forbindelsen blev slettet med succes");//The link was deleted succesfully
define("_LINKS_DELETELINK","Slet link");//Delete link
define("_LINKS_EDITLINK","Rediger link");//Edit link
define("_LINKS_GOTOLINKSPAGE","Gå til Links side");//Go to Links page
?>
