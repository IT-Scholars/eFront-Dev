<?php
define("_LINKS_LINKS","鏈接");//Links
define("_LINKS_LESSONLINK","鏈接");//Links
define("_LINKS_MODULE","鏈接模塊");//Links Module
define("_LINKS_MAIN","主網頁");//Main page
define("_LINKS_MANAGEMENT","管理鏈接");//Manage Links

define("_LINKS_LINKLIST","鏈接");//Links
define("_LINKS_ADDLINK","添加鏈接");//Add Link
define("_LINKS_DISPLAY","顯示文字");//Display text
define("_LINKS_LINK","鏈接");//Link
define("_LINKS_DESCRIPTION","說明");//Description
define("_LINKS_INSERTLINK","添加鏈接");//Add link
define("_LINKS_NOLINKFOUND","沒有聯繫被發現");//No links were found
define("_LINKS_LINKSPAGE","鏈接");//Links
define("_LINKS_SUCCESFULLYINSERTEDLINKENTRY","鏈接插入成功");//The link was inserted succesfully
define("_LINKS_PROBLEMINSERTINGLINKENTRY","出現了問題，而插入鏈接");//A problem occured while inserting the link
define("_LINKS_SUCCESFULLYUPDATEDLINKENTRY","連結已更新成功");//The link was updated succesfully
define("_LINKS_PROBLEMUPDATINGLINKENTRY","出現了問題，而更新的鏈接");//A problem occured while updating the link
define("_LINKS_SUCCESFULLYDELETEDLINK","這個鏈接被刪除成功");//The link was deleted succesfully
define("_LINKS_DELETELINK","刪除鏈接");//Delete link
define("_LINKS_EDITLINK","修改鏈接");//Edit link
define("_LINKS_GOTOLINKSPAGE","進入鏈接頁面");//Go to Links page
?>
