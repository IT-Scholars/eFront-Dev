<?php
define("_MODULE_LEAFLET_MODULELEAFLET", "Hands-on Exercises");
define("_MODULE_LEAFLET_FILESLIST", "Files list");
define("_MODULE_LEAFLET_MANAGEFILES", "Manage files");
?>
